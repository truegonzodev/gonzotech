@echo off
cd /d "%~dp0"
javaw -jar ReaCalc.jar %*
if errorlevel 1 (
  echo ReaCalc requires Java 21 or newer. Try the Windows edition with bundled Java.
  pause
)
