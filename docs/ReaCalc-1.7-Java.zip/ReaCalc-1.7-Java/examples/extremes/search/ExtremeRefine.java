import java.nio.file.*;import java.util.*;
public class ExtremeRefine {
 public static void main(String[] a)throws Exception{
  int n=Integer.parseInt(a[0]);ExtremeSearch.dimension=n;var rng=new Random(99113+n);
  var low=ReactorIO.loadDocument(ExtremeSearch.OUT.resolve("reactor-"+n+"-weak.reacalc"));var best=ReactorIO.loadDocument(ExtremeSearch.OUT.resolve("reactor-"+n+"-strong.reacalc"));ExtremeSearch.evaluate(low.grid());ExtremeSearch.evaluate(best.grid());
  var cur=ExtremeSearch.high;int budget=n==16?900:1200;
  for(int k=0;k<budget;k++){
   if(k%160==0)cur=ExtremeSearch.high;var g=cur.grid().copy();int repeats=1+k%3;
   for(int j=0;j<repeats;j++){
    int i=rng.nextInt(g.size),ii=rng.nextInt(g.size);int x=i%n,y=i/n%n,z=i/n/n,xx=ii%n,yy=ii/n%n,zz=ii/n/n;
    if(k%3!=0){var m=g.get(x,y,z);g.set(x,y,z,g.get(xx,yy,zz));g.set(xx,yy,zz,m);}else{g.set(x,y,z,ExtremeSearch.M[rng.nextInt(6)]);g.set(xx,yy,zz,ExtremeSearch.M[rng.nextInt(6)]);}
   }
   var pair=ExtremeSearch.evaluate(g);var v=pair[1];if(v!=null&&(v.v().usefulOutput()>cur.v().usefulOutput()||rng.nextDouble()<.02&&v.v().usefulOutput()>cur.v().usefulOutput()*.99))cur=v;
   if(k%150==0)System.out.println("REFINE "+n+" k="+k+" Q="+ExtremeSearch.high.v().usefulOutput());
  }
  System.out.println("FINAL HIGH "+ExtremeSearch.high.v());System.out.println("FINAL LOW "+ExtremeSearch.low.v());
  Files.writeString(ExtremeSearch.OUT.resolve("refine-"+n+".txt"),"additionalEvaluations="+ExtremeSearch.evals+"\nHIGH "+ExtremeSearch.high.v()+"\nLOW "+ExtremeSearch.low.v()+"\n");
 }
}
