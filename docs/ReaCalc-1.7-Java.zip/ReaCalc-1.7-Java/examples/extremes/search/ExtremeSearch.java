import java.nio.file.*;import java.util.*;
public class ExtremeSearch {
 static final MatrixCoefficients.Material[] M=MatrixCoefficients.Material.values();
 static final MatrixCoefficients.Material F=M[0],W=M[1],G=M[2],B=M[3],A=M[4],E=M[5];
 static final Path OUT=Path.of("outputs/Reactor-Extremes");
 static record Candidate(MatrixCoefficients.Grid grid,OperatingMetrics.Values v){}
 static Candidate low,high;static int evals,workings;static int dimension;
 static boolean stable(OperatingMetrics.Values v){return !v.overheat()&&v.rods()>0;}
 static boolean working(OperatingMetrics.Values v){return stable(v)&&v.waterTemperature()>=100&&v.waterTemperature()<=300;}
 static void save(String mode,Candidate c)throws Exception{ReactorIO.saveDocument(OUT.resolve("reactor-"+dimension+"-"+mode+".reacalc"),c.grid,c.v.rods());}
 static Candidate[] evaluate(MatrixCoefficients.Grid g)throws Exception{
  var result=ReaCalc.evaluate(g);evals++;int n=result.fuels();if(n==0||result.h()==0)return new Candidate[]{null,null};
  int cap=ReactorIO.capacity(n),max=Math.min(cap,(int)Math.floor((1-1e-8)*n/result.h()));if(max<1)return new Candidate[]{null,null};
  var hv=OperatingMetrics.calculate(result,max);Candidate hc=new Candidate(g,hv),lc=null;
  if(stable(hv)&&(high==null||hv.usefulOutput()>high.v.usefulOutput()+1e-8)){high=hc;save("strong",high);if(evals%20==0||dimension==2)System.out.printf(Locale.ROOT,"HIGH eval%d N%d R%d H%.7f Tw%.3f Q%.6f eta%.4f%n",evals,n,max,hv.htv(),hv.waterTemperature(),hv.usefulOutput(),hv.usefulOutput()/hv.power());}
  if(hv.waterTemperature()>=100){int l=1,h=max;while(l<h){int mid=(l+h)/2;if(OperatingMetrics.calculate(result,mid).waterTemperature()>=100)h=mid;else l=mid+1;}var lv=OperatingMetrics.calculate(result,l);if(working(lv)){workings++;lc=new Candidate(g,lv);if(low==null||lv.usefulOutput()<low.v.usefulOutput()-1e-8){low=lc;save("weak",low);if(evals%20==0||dimension==2)System.out.printf(Locale.ROOT,"LOW eval%d N%d R%d H%.7f Tw%.5f Q%.7f%n",evals,n,l,lv.htv(),lv.waterTemperature(),lv.usefulOutput());}}}
  return new Candidate[]{lc,hc};
 }
 static int depth(int n,int x,int y,int z){return Math.min(Math.min(x,n-1-x),Math.min(Math.min(y,n-1-y),Math.min(z,n-1-z)));}
 static MatrixCoefficients.Grid pattern(int n,int step,int type,int offset){
  var g=new MatrixCoefficients.Grid(n,n,n,G);
  for(int z=0;z<n;z++)for(int y=0;y<n;y++)for(int x=0;x<n;x++){
   int d=depth(n,x,y,z);var m=switch(type){case 0->G;case 1->d==0?W:G;case 2->x%3==0&&z%3==0?W:G;case 3->y%3==0?W:G;case 4->x==n/2?W:G;case 5->d==0?B:G;case 6->x%3==1?G:B;case 7->(x+y+z)%2==0?W:G;case 8->d==0?A:G;case 9->W;case 10->A;case 11->(x+y+z)%3==0?G:W;default->B;};
   if(d>=offset&&(x-offset)%step==0&&(y-offset)%step==0&&(z-offset)%step==0)m=F;
   g.set(x,y,z,m);
  }return g;
 }
 static void exhaustive2()throws Exception{
  int[][] permutations=new int[48][8];int pi=0;int[][] axes={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
  for(int[] axis:axes)for(int flip=0;flip<8;flip++){for(int i=0;i<8;i++){int[] xyz={i&1,(i>>1)&1,(i>>2)&1};int j=0;for(int k=0;k<3;k++)j|=(xyz[axis[k]]^((flip>>k)&1))<<k;permutations[pi][i]=j;}pi++;}
  int total=1;for(int i=0;i<8;i++)total*=6;int[] cells=new int[8];
  for(int code=0;code<total;code++){
   int v=code,fuels=0;for(int i=0;i<8;i++){cells[i]=v%6;v/=6;if(cells[i]==0)fuels++;}if(fuels==0)continue;
   boolean canonical=true;for(int[] permutation:permutations){int other=0;for(int i=7;i>=0;i--)other=6*other+cells[permutation[i]];if(other<code){canonical=false;break;}}if(!canonical)continue;
   var g=new MatrixCoefficients.Grid(2,2,2,E);for(int i=0;i<8;i++)g.set(i&1,(i>>1)&1,(i>>2)&1,M[cells[i]]);evaluate(g);
   if(evals%3000==0)System.out.println("PROGRESS canonical="+evals+" code="+code+"/"+total);
  }
  System.out.println("EXHAUSTIVE complete colourings="+total+" canonicalWithFuel="+evals+" workingLayouts="+workings);
 }
 static double scoreHigh(Candidate c){if(c==null)return -1e99;return c.v.usefulOutput();}
 static double scoreLow(Candidate c){if(c==null)return -1e99;return -c.v.usefulOutput();}
 static void search(int n)throws Exception{
  var rng=new Random(60123+n);ArrayList<Candidate> elites=new ArrayList<>();
  Path seed=Path.of("outputs/ReaCalc/examples/tutorials/tutorial-"+n+".reacalc");evaluate(ReactorIO.load(seed));
  if(n==16)evaluate(ReactorIO.load(Path.of("outputs/ReaCalc/examples/tutorials/188-working.reacalc")));
  for(int step:new int[]{1,2,3,4,6})for(int type=0;type<13;type++)for(int offset=0;offset<=1;offset++){
   var pair=evaluate(pattern(n,step,type,offset));if(pair[1]!=null)elites.add(pair[1]);
  }
  elites.sort((a,b)->Double.compare(scoreHigh(b),scoreHigh(a)));if(elites.size()>8)elites.subList(8,elites.size()).clear();
  System.out.println("PATTERNS complete "+evals+" high="+high.v+" low="+(low==null?null:low.v));
  for(int phase=0;phase<2;phase++){
   Candidate current=phase==0?high:low;int stagnant=0;int budget=n==5?1400:n==10?650:550;
   for(int k=0;k<budget;k++){
    if(k%140==0){if(phase==0&&k>0&&k/140<elites.size())current=elites.get(k/140);else current=phase==0?high:low;}
    var g=current.grid.copy();int mutations=k%7==0?Math.max(2,g.size/150):1;
    for(int j=0;j<mutations;j++){int i=rng.nextInt(g.size),x=i%n,y=i/n%n,z=i/(n*n);g.set(x,y,z,M[rng.nextInt(6)]);}
    // Occasional coherent patch permits escaping isolated local changes.
    if(k%41==0){int axis=rng.nextInt(3),at=rng.nextInt(n);var mat=M[1+rng.nextInt(4)];for(int z=0;z<n;z++)for(int y=0;y<n;y++)for(int x=0;x<n;x++)if((axis==0?x:axis==1?y:z)==at&&g.get(x,y,z)!=F)g.set(x,y,z,mat);}
    var pair=evaluate(g);Candidate next=pair[phase==0?1:0];double a=phase==0?scoreHigh(current):scoreLow(current),b=phase==0?scoreHigh(next):scoreLow(next);
    if(next!=null&&(b>a||rng.nextDouble()<.015&&b>a-Math.abs(a)*.025)){current=next;stagnant=0;}else stagnant++;
    if(stagnant>80){current=phase==0?high:low;stagnant=0;}
    if(k%100==0)System.out.println("SEARCH phase="+phase+" k="+k+" evals="+evals+" highQ="+high.v.usefulOutput()+" lowQ="+low.v.usefulOutput());
   }
  }
 }
 public static void main(String[] args)throws Exception{
  dimension=Integer.parseInt(args[0]);Files.createDirectories(OUT);if(dimension==2)exhaustive2();else search(dimension);
  System.out.println("FINAL HIGH "+high.v);System.out.println("FINAL LOW "+low.v);Files.writeString(OUT.resolve("search-"+dimension+".txt"),"evaluations="+evals+"\nworkingLayouts="+workings+"\nHIGH "+high.v+"\nLOW "+low.v+"\n");
 }
}
