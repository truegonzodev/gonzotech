final class HeatOutputCurveTest {
 static void close(double a,double b,String m){ReaCalcTest.close(a,b,1e-7,m);}
 static void check(boolean b,String m){ReaCalcTest.check(b,m);}
 static void run()throws Exception{
  for(int index=0;index<24;index++){
   var doc=TutorialCatalog.load(index);var raw=ReaCalc.evaluate(doc.grid());var curve=new HeatOutputCurve(raw);
   for(int rods=0;rods<=Math.min(raw.fuels()+2,18);rods++){
    var v=OperatingMetrics.calculate(raw,rods);if(v.overheat())continue;
    var out=curve.at(v.hotTemperature());close(out.exchange(),v.output(),"all stable plateaus exchange");close(out.useful(),v.usefulOutput(),"all stable plateaus useful");
   }
   double q=0,p=0;
   for(double t=20;t<=10000;t+=97){
    var out=curve.at(t);check(Double.isFinite(out.exchange())&&out.exchange()>=q-1e-8,"finite monotonic exchange");check(out.useful()>=p-1e-8&&out.useful()<=out.exchange()+1e-8,"monotonic useful within exchange");q=out.exchange();p=out.useful();
   }
   var left=curve.at(curve.anchorTemperature-1e-7);var right=curve.at(curve.anchorTemperature+1e-7);
   check(Math.abs(left.exchange()-right.exchange())<1e-4&&Math.abs(left.useful()-right.useful())<1e-4,"continuous at critical temperature");
  }
  var doc=TutorialCatalog.load(5);var raw=ReaCalc.evaluate(doc.grid());check(raw.grid().nx==7,"reported tutorial7 fixture");
  var s=new HeatDynamics.State();s.configure(HeatDynamics.parameters(raw,OperatingMetrics.calculate(raw,2)));
  var random=new java.util.Random(17);
  for(double t:new double[]{20,1000,2151,2858,3095,5000,9000}){
   s.base=t;s.excess=0;double beforeP=s.useful(),beforeQ=s.exchange();
   for(int i=0;i<100;i++){
    int rods=i<30?i%3:random.nextInt(11);s.configure(HeatDynamics.parameters(raw,OperatingMetrics.calculate(raw,rods)));
    close(s.temperature(),t,"rods0to10 keep temperature");close(s.useful(),beforeP,"rods0to10 no useful step");close(s.exchange(),beforeQ,"rods0to10 no exchange step");
   }
  }
  var a=new HeatDynamics.State();var b=new HeatDynamics.State();
  a.configure(HeatDynamics.parameters(raw,OperatingMetrics.calculate(raw,1)));
  b.configure(HeatDynamics.parameters(raw,OperatingMetrics.calculate(raw,2)));
  a.base=b.base=3095;a.excess=b.excess=0;close(a.useful(),b.useful(),"no startup loading memory");close(a.exchange(),b.exchange(),"no last rod coefficient memory");
  a.configure(HeatDynamics.parameters(raw,OperatingMetrics.calculate(raw,0)));double p=a.useful();a.advance(100);check(a.useful()<p&&a.useful()>0,"zero rods releases stored heat by same curve");
  a.reset();check(a.useful()==0&&a.exchange()==0,"cold empty zero output");a.base=9000;a.destroyed=true;check(a.useful()==0&&a.exchange()==0,"destroyed zero output");
 }
}

