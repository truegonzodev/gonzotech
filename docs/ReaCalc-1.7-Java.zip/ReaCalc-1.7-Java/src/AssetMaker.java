import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.nio.*;
import java.nio.file.*;
import javax.imageio.ImageIO;

/** All artwork is drawn procedurally; this only creates the Windows launcher icon. */
final class AssetMaker {
    static BufferedImage icon(){BufferedImage image=new BufferedImage(128,128,BufferedImage.TYPE_INT_ARGB);Graphics2D g=image.createGraphics();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(23,28,46));g.fillRoundRect(0,0,128,128,28,28);
        g.setPaint(new RadialGradientPaint(64,60,56,new float[]{0,.3f,.65f,1},new Color[]{new Color(255,246,195,255),new Color(255,160,43,230),new Color(171,41,132,140),new Color(84,34,127,0)}));g.fillOval(8,4,112,112);
        g.setStroke(new BasicStroke(3));g.setColor(new Color(106,236,208));int[][] p={{64,24},{99,44},{99,84},{64,104},{29,84},{29,44}};for(int i=0;i<6;i++)g.drawLine(p[i][0],p[i][1],p[(i+1)%6][0],p[(i+1)%6][1]);g.drawLine(29,44,64,64);g.drawLine(99,44,64,64);g.drawLine(64,64,64,104);g.dispose();return image;
    }
    static void create(Path root)throws Exception{
        Files.createDirectories(root.resolve("examples"));Path e=root.resolve("examples");
        ReactorIO.save(e.resolve("field-and-boron.reacalc"),ReaCalc.demo());
        ReactorIO.save(e.resolve("reference-070.json"),MatrixCoefficients.referenceLayout());
        ReactorIO.save(e.resolve("27-fuel.reacalc"),new MatrixCoefficients.Grid(3,3,3,MatrixCoefficients.Material.FUEL));
        ReactorIO.save(e.resolve("188-fuel.reacalc"),ReaCalc.resource188());
        for(var m:new MatrixCoefficients.Material[]{MatrixCoefficients.Material.WATER,MatrixCoefficients.Material.GRAPHITE,MatrixCoefficients.Material.BORON})ReactorIO.save(e.resolve("fuel-in-"+m.name().toLowerCase(java.util.Locale.ROOT)+".reacalc"),ReaCalc.surrounded(m));
        ByteArrayOutputStream png=new ByteArrayOutputStream();ImageIO.write(icon(),"png",png);byte[] bytes=png.toByteArray();ByteBuffer header=ByteBuffer.allocate(22).order(ByteOrder.LITTLE_ENDIAN);header.putShort((short)0).putShort((short)1).putShort((short)1);header.put((byte)128).put((byte)128).put((byte)0).put((byte)0).putShort((short)1).putShort((short)32).putInt(bytes.length).putInt(22);
        ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(header.array());out.write(bytes);Files.write(root.resolve("ReaCalc.ico"),out.toByteArray());
        System.out.println("Examples and procedural icon created in "+root.toAbsolutePath());
    }
}
