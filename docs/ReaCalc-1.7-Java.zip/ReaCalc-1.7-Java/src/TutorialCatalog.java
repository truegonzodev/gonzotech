import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class TutorialCatalog {
    record Entry(String title,String file,String lesson){}
    static final List<Entry> ENTRIES;
    static {
        ArrayList<Entry> list=new ArrayList<>();
        for(int n=2;n<=16;n++)list.add(new Entry("Учебный "+n+"×"+n+"×"+n,"tutorial-"+n+".reacalc",
                n==2?"Минимальный объём: вода и четыре чехла; 5 ТВЭЛов. Небольшой полезный выход показывает цену компактности."
                :"Учебная "+n+"³: "+structure(n)+". Загрузка подобрана для воды 100–300 °C; попробуйте заменить часть графита бором."));
        list.add(new Entry("188 чехлов · rawH ≈ 10,44","188-working.reacalc",
                "188 чехлов, 18 ТВЭЛов: графит усиливает нагрев, поглотители ограничивают его. rawH ≈ 10,44; близко к пределу Htv=1."));
        for(int n:new int[]{2,5,10,16}){
            list.add(new Entry(n+"³ · слабый рабочий","reactor-"+n+"-weak.reacalc","Слабый "+n+"³: минимальный найденный полезный выход при воде 100–300 °C. Загрузка сохранена; коэффициенты модели не менялись."));
            list.add(new Entry(n+"³ · максимум мощности","reactor-"+n+"-strong.reacalc","Сильный "+n+"³: максимум найденного Pполезное при Htv < 1. "+(n==2?"Полный перебор 2³.":"Вода выше 300 °C допустима в этом сравнении; глобальный оптимум не доказан.")));
        }
        ENTRIES=List.copyOf(list);
    }
    static String structure(int n){return switch(n){
        case 3->"шахматное чередование графита и воды вокруг одного чехла";
        case 4,5->"водяные слои через два графитовых, один чехол";
        case 12,13,14->"графитовые плоскости между борными, разреженные чехлы";
        default->"борная внешняя оболочка, графитовый объём, разреженная сетка чехлов";
    };}
    static ReactorIO.Document load(int index)throws IOException{
        Entry entry=ENTRIES.get(index);
        try(var in=TutorialCatalog.class.getResourceAsStream("/tutorials/"+entry.file())){
            if(in==null)throw new IOException("Учебный пример отсутствует: "+entry.file());
            return ReactorIO.decodeDocument(new String(in.readAllBytes(),StandardCharsets.UTF_8));
        }
    }
}
