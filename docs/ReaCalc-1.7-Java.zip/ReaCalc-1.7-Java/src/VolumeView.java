import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/** Orthographic 3D camera and software volume ray marcher. No sprites or external assets. */
final class VolumeView extends JPanel {
    record Result(MatrixCoefficients.Grid grid,MatrixCoefficients.Raw raw,double h,double l,int fuels){}
    record Camera(double yaw,double pitch,double zoom,double panX,double panY){}
    record Projected(double x,double y,double depth){}
    record Settings(int mode,int cut,int layer,double exposure,boolean blocks){}
    record Scene(Result result,Camera camera,Settings settings,int width,int height){}
    interface Pick {void select(int x,int y,int z,boolean paint,boolean erase);}
    static final Color BACK=new Color(24,25,44);
    Result result;
    double yaw=-.68,pitch=.48,zoom=1.25,panX=0,panY=0,exposure=4;
    int mode=0,cut=0,layer=4,selected=-1;
    boolean blocks=true;
    private BufferedImage volume;
    private Scene volumeScene;
    private Point last,press;
    private int dragButton;
    final Pick pick;
    final ExecutorService renderer=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"reacalc-volume");t.setDaemon(true);return t;});
    Future<?> pending;
    final AtomicLong generation=new AtomicLong();
    final javax.swing.Timer debounce,settle;
    boolean moving;
    long renderMillis;
    VolumeView(Pick pick){
        this.pick=pick;setBackground(BACK);setPreferredSize(new Dimension(800,680));setFocusable(true);
        debounce=new javax.swing.Timer(40,e->submitRender());debounce.setRepeats(false);
        settle=new javax.swing.Timer(160,e->{moving=false;requestRender();});settle.setRepeats(false);
        addComponentListener(new ComponentAdapter(){public void componentResized(ComponentEvent e){requestRender();}});
        MouseAdapter mouse=new MouseAdapter(){
            public void mousePressed(MouseEvent e){requestFocusInWindow();last=press=e.getPoint();dragButton=e.getButton();}
            public void mouseDragged(MouseEvent e){if(last==null)return;int dx=e.getX()-last.x,dy=e.getY()-last.y;
                if(dragButton==MouseEvent.BUTTON3||dragButton==MouseEvent.BUTTON2){panX+=dx;panY+=dy;}
                else{yaw+=dx*.009;pitch=Math.max(-1.45,Math.min(1.45,pitch+dy*.009));}
                last=e.getPoint();moving=true;requestRender();settle.restart();
            }
            public void mouseReleased(MouseEvent e){if(press!=null&&press.distance(e.getPoint())<4)pickAt(e.getX(),e.getY(),e.isShiftDown(),SwingUtilities.isRightMouseButton(e)&&e.isShiftDown());last=null;press=null;moving=false;requestRender();}
            public void mouseWheelMoved(MouseWheelEvent e){zoom=Math.max(.35,Math.min(4,zoom*Math.pow(1.12,-e.getPreciseWheelRotation())));moving=true;requestRender();settle.restart();}
        };addMouseListener(mouse);addMouseMotionListener(mouse);addMouseWheelListener(mouse);
        setToolTipText("ЛКМ — вращать; ПКМ — сдвигать; колесо — масштаб; Shift + щелчок — рисовать в активном слое");
    }
    void setResult(Result r){result=r;volume=null;volumeScene=null;requestRender();}
    void clearField(){result=null;volume=null;generation.incrementAndGet();if(pending!=null)pending.cancel(true);repaint();}
    void reset(){yaw=-.68;pitch=.48;zoom=1.25;panX=panY=0;requestRender();}
    void renderNow(){if(result==null)return;volumeScene=new Scene(result,camera(),settings(),getWidth(),getHeight());volume=renderVolume(volumeScene,Math.min(700,getWidth()));}
    Camera camera(){return new Camera(yaw,pitch,zoom,panX,panY);}
    Settings settings(){return new Settings(mode,cut,layer,exposure,blocks);}
    void requestRender(){generation.incrementAndGet();debounce.restart();repaint();}
    void submitRender(){
        if(result==null||getWidth()<1||getHeight()<1)return;
        long token=generation.get();Scene scene=new Scene(result,camera(),settings(),getWidth(),getHeight());
        int target=moving?210:460;
        if(pending!=null)pending.cancel(true);
        pending=renderer.submit(()->{
            long start=System.nanoTime();BufferedImage image=renderVolume(scene,target);
            if(image==null)return;long ms=(System.nanoTime()-start)/1_000_000;
            SwingUtilities.invokeLater(()->{if(token==generation.get()){volume=image;volumeScene=scene;renderMillis=ms;repaint();}});
        });
    }
    void shutdown(){debounce.stop();settle.stop();renderer.shutdownNow();}
    static double scale(Scene s){var g=s.result.grid;double diagonal=Math.sqrt(g.nx*g.nx+g.ny*g.ny+g.nz*g.nz);return Math.min(s.width,s.height)*.84/diagonal*s.camera.zoom;}
    static double[][] basis(Camera c){double sy=Math.sin(c.yaw),cy=Math.cos(c.yaw),sp=Math.sin(c.pitch),cp=Math.cos(c.pitch);return new double[][]{{cy,0,-sy},{sy*sp,cp,cy*sp},{sy*cp,-sp,cy*cp}};}
    static Projected project(Scene s,double x,double y,double z){var g=s.result.grid;x-=g.nx*.5;y-=g.ny*.5;z-=g.nz*.5;double[][] b=basis(s.camera);double sc=scale(s);
        return new Projected(s.width*.5+s.camera.panX+sc*(x*b[0][0]+y*b[0][1]+z*b[0][2]),s.height*.5+s.camera.panY-sc*(x*b[1][0]+y*b[1][1]+z*b[1][2]),x*b[2][0]+y*b[2][1]+z*b[2][2]);}
    static double[] ray(Scene s,double px,double py){double sc=scale(s);double vx=(px-s.width*.5-s.camera.panX)/sc,vy=-(py-s.height*.5-s.camera.panY)/sc;double[][] b=basis(s.camera);var g=s.result.grid;double d=Math.max(g.nx,Math.max(g.ny,g.nz))*3;
        return new double[]{g.nx*.5+b[0][0]*vx+b[1][0]*vy+b[2][0]*d,g.ny*.5+b[0][1]*vx+b[1][1]*vy+b[2][1]*d,g.nz*.5+b[0][2]*vx+b[1][2]*vy+b[2][2]*d,-b[2][0],-b[2][1],-b[2][2]};}
    static double[] intersect(double[] r,double x0,double y0,double z0,double x1,double y1,double z1){double a=0,b=Double.POSITIVE_INFINITY;double[] lo={x0,y0,z0},hi={x1,y1,z1};
        for(int k=0;k<3;k++){if(Math.abs(r[k+3])<1e-12){if(r[k]<lo[k]||r[k]>hi[k])return null;}else{double t0=(lo[k]-r[k])/r[k+3],t1=(hi[k]-r[k])/r[k+3];a=Math.max(a,Math.min(t0,t1));b=Math.min(b,Math.max(t0,t1));if(a>b)return null;}}
        return new double[]{a,b};}
    static BufferedImage renderVolume(Scene s,int targetWidth){
        int w=Math.max(1,Math.min(targetWidth,s.width)),h=Math.max(1,(int)Math.round((double)s.height*w/s.width));
        BufferedImage image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);int[] pixels=new int[w*h];
        var grid=s.result.grid;var data=s.result.raw;double z0=s.settings.cut==1?s.settings.layer:0,z1=s.settings.cut==0?grid.nz:s.settings.layer+1;
        double[][] fields=displayFields(grid,data,s.settings.mode);
        double[] sample=new double[3];double step=.24;
        for(int py=0;py<h;py++){
            if(Thread.currentThread().isInterrupted())return null;
            for(int px=0;px<w;px++){
                double[] r=ray(s,(px+.5)*s.width/w,(py+.5)*s.height/h);double[] hit=intersect(r,0,0,z0,grid.nx,grid.ny,z1);if(hit==null)continue;
                double rr=0,gg=0,bb=0,alpha=0;
                for(double t=hit[0]+step*.5;t<hit[1]&&alpha<.985;t+=step){
                    double x=r[0]+r[3]*t,y=r[1]+r[4]*t,z=r[2]+r[5]*t;
                    sample(grid,fields,x,y,z,sample);
                    double total=sample[0];if(total<1e-9)continue;
                    double intensity=Math.log1p(total*s.settings.exposure*12);
                    double strength=1-Math.exp(-intensity*.9);
                    double warmth=strength*(s.settings.mode==0?1-.38*sample[1]:1);
                    int color=palette(warmth);double a=(1-Math.exp(-intensity*.48*step))*(1-alpha);
                    rr+=a*((color>>16)&255);gg+=a*((color>>8)&255);bb+=a*(color&255);alpha+=a;
                }
                if(alpha>1e-6)pixels[py*w+px]=((int)Math.min(255,alpha*255)<<24)|((int)Math.min(255,rr/alpha)<<16)|((int)Math.min(255,gg/alpha)<<8)|(int)Math.min(255,bb/alpha);
            }
        }image.setRGB(0,0,w,h,pixels,0,w);return image;
    }
    // Optical interpolation only. Never average across different materials or change H/L.
    static double[][] displayFields(MatrixCoefficients.Grid g,MatrixCoefficients.Raw r,int mode){
        double[] total=new double[g.size],slow=new double[g.size];
        for(int i=0;i<g.size;i++){total[i]=switch(mode){case 1->r.fastField()[i];case 2->r.slowField()[i];case 3->r.absorptionField()[i];case 4->r.load()[i]/ReaCalc.HEAT_BUDGET;default->r.fastField()[i]+r.slowField()[i];};slow[i]=mode==0?r.slowField()[i]:0;}
        if(mode<=2)for(int pass=0;pass<2;pass++){
            double[] next=total.clone(),nextSlow=slow.clone();
            for(int z=0;z<g.nz;z++)for(int y=0;y<g.ny;y++)for(int x=0;x<g.nx;x++){
                var m=g.get(x,y,z);if(m==MatrixCoefficients.Material.FUEL)continue;int i=g.index(x,y,z);double sum=0,sumSlow=0,weights=0;
                for(int dz=-1;dz<=1;dz++)for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
                    int xx=x+dx,yy=y+dy,zz=z+dz;if(!g.inside(xx,yy,zz)||g.get(xx,yy,zz)!=m)continue;
                    double w=Math.exp(-(dx*dx+dy*dy+dz*dz)/1.1);int j=g.index(xx,yy,zz);sum+=w*total[j];sumSlow+=w*slow[j];weights+=w;
                }next[i]=sum/weights;nextSlow[i]=sumSlow/weights;
            }total=next;slow=nextSlow;
        }return new double[][]{total,slow};
    }
    static void sample(MatrixCoefficients.Grid g,double[][] fields,double x,double y,double z,double[] out){
        x=Math.max(0,Math.min(g.nx-1,x-.5));y=Math.max(0,Math.min(g.ny-1,y-.5));z=Math.max(0,Math.min(g.nz-1,z-.5));
        int ix=(int)x,iy=(int)y,iz=(int)z;double fx=x-ix,fy=y-iy,fz=z-iz;double total=0,slow=0;
        for(int dz=0;dz<2;dz++)for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++){
            int i=Math.min(ix+dx,g.nx-1)+g.nx*(Math.min(iy+dy,g.ny-1)+g.ny*Math.min(iz+dz,g.nz-1));
            double weight=(dx==0?1-fx:fx)*(dy==0?1-fy:fy)*(dz==0?1-fz:fz);
            total+=fields[0][i]*weight;slow+=fields[1][i]*weight;
        }out[0]=total;out[1]=total>0?Math.min(1,slow/total):0;
    }
    static final int[] COLORS={0x56227f,0x9421a8,0xd82f66,0xf25b24,0xffaf22,0xfff3b7,0xffffff};
    static int palette(double t){
        int[] colors=COLORS;
        double u=Math.max(0,Math.min(.999999,t))*(colors.length-1);int i=(int)u;double f=u-i;int a=colors[i],b=colors[i+1];
        return ((int)(((a>>16)&255)*(1-f)+((b>>16)&255)*f)<<16)|((int)(((a>>8)&255)*(1-f)+((b>>8)&255)*f)<<8)|(int)((a&255)*(1-f)+(b&255)*f);
    }
    static Color materialColor(MatrixCoefficients.Material m){return switch(m){case FUEL->new Color(255,219,123);case WATER->new Color(91,173,255);case GRAPHITE->new Color(176,149,236);case BORON->new Color(60,211,181);case BARIUM->new Color(240,146,109);case EMPTY->new Color(75,82,104);};}
    boolean visible(int z){return cut==0||cut==1&&z==layer||cut==2&&z<=layer;}
    @Override protected void paintComponent(Graphics graphics){super.paintComponent(graphics);Graphics2D g=(Graphics2D)graphics.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        g.setPaint(new GradientPaint(0,0,new Color(31,31,52),getWidth(),getHeight(),new Color(15,19,33)));g.fillRect(0,0,getWidth(),getHeight());
        if(result==null){g.setColor(new Color(166,175,199));g.drawString("Расчёт поля…",30,40);g.dispose();return;}
        Scene scene=new Scene(result,camera(),settings(),getWidth(),getHeight());
        if(volume!=null&&volumeScene!=null&&volumeScene.camera.equals(scene.camera)&&volumeScene.settings.equals(scene.settings)){
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);g.drawImage(volume,0,0,getWidth(),getHeight(),null);
        }
        drawGeometry(g,scene,selected);
        g.setColor(new Color(201,208,226));g.setFont(new Font("Segoe UI",Font.PLAIN,12));
        g.drawString("ЛКМ: вращать   ·   ПКМ: сдвиг   ·   колесо: масштаб",22,getHeight()-26);
        g.setColor(new Color(132,144,171));g.drawString("Shift + щелчок: блок в активном слое",22,getHeight()-9);
        drawLegend(g,getWidth()-228,22,200,mode);
        g.dispose();
    }
    static void drawLegend(Graphics2D g,int x,int y,int w,int mode){
        g.setFont(new Font("Segoe UI",Font.PLAIN,11));g.setColor(new Color(194,201,224));g.drawString(mode==4?"Тепловая нагрузка":mode==3?"Поглощение":mode==0?"Поток и замедление":"Интенсивность компоненты",x,y);
        for(int i=0;i<w;i++){g.setColor(new Color(palette((double)i/(w-1))));g.drawLine(x+i,y+10,x+i,y+14);}
        g.setColor(new Color(150,159,184));g.drawString("слабее",x,y+31);g.drawString("сильнее",x+w-43,y+31);
    }
    static void drawGeometry(Graphics2D g,Scene s,int selected){
        var grid=s.result.grid;var set=s.settings;List<int[]> cells=new ArrayList<>();
        if(set.blocks)for(int z=0;z<grid.nz;z++)if(set.cut==0||set.cut==1&&z==set.layer||set.cut==2&&z<=set.layer)
            for(int y=0;y<grid.ny;y++)for(int x=0;x<grid.nx;x++)if(grid.get(x,y,z)!=MatrixCoefficients.Material.EMPTY)cells.add(new int[]{x,y,z});
        cells.sort(Comparator.comparingDouble(p->project(s,p[0]+.5,p[1]+.5,p[2]+.5).depth));
        boolean dense=cells.size()>450;
        for(int[] p:cells){var m=grid.get(p[0],p[1],p[2]);Color c=materialColor(m);int alpha=m==MatrixCoefficients.Material.FUEL?190:dense?40:125;
            drawBox(g,s,p[0]+.04,p[1]+.04,p[2]+.04,p[0]+.96,p[1]+.96,p[2]+.96,new Color(c.getRed(),c.getGreen(),c.getBlue(),alpha),m==MatrixCoefficients.Material.FUEL?1.6f:.85f);
        }
        drawBox(g,s,0,0,0,grid.nx,grid.ny,grid.nz,new Color(132,151,184,55),1);
        if(selected>=0&&selected<grid.size){int x=selected%grid.nx,y=selected/grid.nx%grid.ny,z=selected/(grid.nx*grid.ny);
            if(set.cut==0||set.cut==1&&z==set.layer||set.cut==2&&z<=set.layer)drawBox(g,s,x,y,z,x+1,y+1,z+1,new Color(235,245,255,235),2);}
        Projected origin=project(s,0,0,0);String[] names={"X","Y","Z"};Color[] colors={new Color(255,124,143),new Color(118,220,172),new Color(116,169,255)};
        double[][] endpoints={{2,0,0},{0,2,0},{0,0,2}};
        for(int i=0;i<3;i++){Projected end=project(s,endpoints[i][0],endpoints[i][1],endpoints[i][2]);g.setColor(colors[i]);g.setStroke(new BasicStroke(2));g.drawLine((int)origin.x,(int)origin.y,(int)end.x,(int)end.y);g.drawString(names[i],(int)end.x+4,(int)end.y-4);}
    }
    static void drawBox(Graphics2D g,Scene s,double x0,double y0,double z0,double x1,double y1,double z1,Color color,float stroke){
        Projected[] p=new Projected[8];for(int i=0;i<8;i++)p[i]=project(s,(i&1)==0?x0:x1,(i&2)==0?y0:y1,(i&4)==0?z0:z1);
        g.setColor(color);g.setStroke(new BasicStroke(stroke));for(int i=0;i<8;i++)for(int bit:new int[]{1,2,4})if((i&bit)==0){var a=p[i];var b=p[i|bit];g.drawLine((int)a.x,(int)a.y,(int)b.x,(int)b.y);}
    }
    void pickAt(int px,int py,boolean paint,boolean erase){
        if(result==null)return;Scene s=new Scene(result,camera(),settings(),getWidth(),getHeight());double[] r=ray(s,px,py);var grid=result.grid;
        if(paint){if(Math.abs(r[5])<1e-9)return;double t=(layer+.5-r[2])/r[5];int x=(int)Math.floor(r[0]+t*r[3]),y=(int)Math.floor(r[1]+t*r[4]);if(grid.inside(x,y,layer))pick.select(x,y,layer,true,erase);return;}
        double closest=Double.POSITIVE_INFINITY;int[] found=null;
        for(int z=0;z<grid.nz;z++)if(visible(z))for(int y=0;y<grid.ny;y++)for(int x=0;x<grid.nx;x++)if(grid.get(x,y,z)!=MatrixCoefficients.Material.EMPTY){double[] hit=intersect(r,x,y,z,x+1,y+1,z+1);if(hit!=null&&hit[0]<closest){closest=hit[0];found=new int[]{x,y,z};}}
        if(found!=null)pick.select(found[0],found[1],found[2],false,false);
    }
}
