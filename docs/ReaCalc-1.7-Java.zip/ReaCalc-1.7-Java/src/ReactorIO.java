import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;

/** Strict, dependency-free configuration format. Both extensions contain UTF-8 JSON. */
final class ReactorIO {
    record Document(MatrixCoefficients.Grid grid,int loadedRods) {}
    static int capacity(int sleeves){return sleeves<=0?0:Math.min(sleeves+2,18);}
    static int countSleeves(MatrixCoefficients.Grid g){int n=0;for(int z=0;z<g.nz;z++)for(int y=0;y<g.ny;y++)for(int x=0;x<g.nx;x++)if(g.get(x,y,z)==MatrixCoefficients.Material.FUEL)n++;return n;}
    static void validateRods(MatrixCoefficients.Grid g,int rods){if(rods<0||rods>capacity(countSleeves(g)))throw new IllegalArgumentException("Загрузка ТВЭЛов превышает число слотов или отрицательна.");}
    static String encodeDocument(MatrixCoefficients.Grid g,int rods){validateRods(g,rods);return encode(g).replace("\"version\": 1,","\"version\": 2,\n  \"loadedRods\": "+rods+",");}
    static String encode(MatrixCoefficients.Grid g) {
        StringBuilder s = new StringBuilder("{\n  \"format\": \"reacalc\",\n  \"version\": 1,\n  \"size\": ["+g.nx+", "+g.ny+", "+g.nz+"],\n  \"cells\": [\n");
        for(int z=0;z<g.nz;z++)for(int y=0;y<g.ny;y++){
            s.append("    ");
            for(int x=0;x<g.nx;x++){
                if(x>0)s.append(' ');
                s.append('"').append(g.get(x,y,z).name()).append('"');
                if(g.index(x,y,z)<g.size-1)s.append(',');
            }s.append('\n');
        }return s.append("  ]\n}\n").toString();
    }
    static void save(Path target,MatrixCoefficients.Grid g)throws IOException{
        write(target,encode(g));
    }
    static void saveDocument(Path target,MatrixCoefficients.Grid g,int rods)throws IOException{
        write(target,encodeDocument(g,rods));
    }
    static void write(Path target,String text)throws IOException{
        Path absolute=target.toAbsolutePath();Path temp=Files.createTempFile(absolute.getParent(),".reacalc-",".tmp");
        try{
            Files.writeString(temp,text,StandardCharsets.UTF_8);
            try{Files.move(temp,absolute,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException ex){Files.move(temp,absolute,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(temp);}
    }
    static MatrixCoefficients.Grid load(Path path)throws IOException{
        return loadDocument(path).grid();
    }
    static Document loadDocument(Path path)throws IOException{
        if(Files.size(path)>1_000_000)throw new IllegalArgumentException("Файл превышает 1 МБ.");
        String text=Files.readString(path,StandardCharsets.UTF_8);
        if(text.startsWith("\uFEFF"))text=text.substring(1);
        return path.toString().toLowerCase(Locale.ROOT).endsWith(".txt")?new Document(decodeLegacy(text),0):decodeDocument(text);
    }
    static MatrixCoefficients.Grid decode(String text){
        return decodeDocument(text).grid();
    }
    static Document decodeDocument(String text){
        Object value=new Parser(text).parse();
        if(!(value instanceof Map<?,?> m))throw new IllegalArgumentException("Ожидается JSON-объект.");
        if(!"reacalc".equals(m.get("format")))throw new IllegalArgumentException("Неизвестный формат. Ожидается format: reacalc.");
        int version=integer(m.get("version"));if(version!=1&&version!=2)throw new IllegalArgumentException("Поддерживаются версии 1 и 2.");
        if(!(m.get("size") instanceof List<?> dims)||dims.size()!=3)throw new IllegalArgumentException("size должен содержать X, Y, Z.");
        int nx=dimension(dims.get(0)),ny=dimension(dims.get(1)),nz=dimension(dims.get(2));
        if(!(m.get("cells") instanceof List<?> cells)||cells.size()!=nx*ny*nz)throw new IllegalArgumentException("Число клеток не совпадает с размером.");
        var g=new MatrixCoefficients.Grid(nx,ny,nz,MatrixCoefficients.Material.EMPTY);
        for(int i=0;i<cells.size();i++){
            if(!(cells.get(i) instanceof String name))throw new IllegalArgumentException("Материал должен быть строкой, клетка "+i);
            MatrixCoefficients.Material material;
            try{material=MatrixCoefficients.Material.valueOf(name);}catch(IllegalArgumentException ex){throw new IllegalArgumentException("Неизвестный материал: "+name);}
            g.set(i%nx,(i/nx)%ny,i/(nx*ny),material);
        }
        int rods=version==2?integer(m.get("loadedRods")):0;validateRods(g,rods);return new Document(g,rods);
    }
    static int integer(Object n){if(!(n instanceof Double d)||!Double.isFinite(d)||d!=Math.rint(d)||d<Integer.MIN_VALUE||d>Integer.MAX_VALUE)throw new IllegalArgumentException("Ожидается целое число.");return ((Double)n).intValue();}
    static int dimension(Object n){int d=integer(n);if(d<1||d>16)throw new IllegalArgumentException("Размер каждой оси: от 1 до 16.");return d;}
    static MatrixCoefficients.Grid decodeLegacy(String text){
        var lines=text.lines().map(String::strip).filter(s->!s.isEmpty()&&!s.startsWith("#")).toList();
        if(lines.isEmpty())throw new IllegalArgumentException("Пустой файл.");String[] d=lines.getFirst().split("\\s+");
        if(d.length!=3)throw new IllegalArgumentException("Ожидаются размеры X Y Z.");
        int nx=dimension(Double.valueOf(d[0])),ny=dimension(Double.valueOf(d[1])),nz=dimension(Double.valueOf(d[2]));
        if(lines.size()!=1+ny*nz)throw new IllegalArgumentException("Некорректное количество строк.");
        var g=new MatrixCoefficients.Grid(nx,ny,nz,MatrixCoefficients.Material.EMPTY);
        for(int z=0;z<nz;z++)for(int y=0;y<ny;y++){
            String row=lines.get(1+z*ny+y);if(row.length()!=nx)throw new IllegalArgumentException("Некорректная длина строки.");
            for(int x=0;x<nx;x++)g.set(x,y,z,switch(row.charAt(x)){
                case 'F'->MatrixCoefficients.Material.FUEL;case 'W'->MatrixCoefficients.Material.WATER;
                case 'B'->MatrixCoefficients.Material.BORON;case 'G'->MatrixCoefficients.Material.GRAPHITE;
                case 'A'->MatrixCoefficients.Material.BARIUM;case '.'->MatrixCoefficients.Material.EMPTY;
                default->throw new IllegalArgumentException("Неизвестный символ материала.");});
        }return g;
    }
    static final class Parser {
        final String s;int p,depth;
        Parser(String s){this.s=s;if(s.length()>1_000_000)throw new IllegalArgumentException("Слишком большой JSON.");}
        IllegalArgumentException fail(){return new IllegalArgumentException("Некорректный JSON около позиции "+p);}
        void ws(){while(p<s.length()&&" \t\r\n".indexOf(s.charAt(p))>=0)p++;}
        boolean take(char c){ws();if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}
        void need(char c){if(!take(c))throw fail();}
        Object parse(){Object out=value();ws();if(p!=s.length())throw fail();return out;}
        Object value(){ws();if(++depth>24||p>=s.length())throw fail();try{
            char c=s.charAt(p);
            if(c=='"')return string();
            if(c=='{'){p++;Map<String,Object> m=new LinkedHashMap<>();if(take('}'))return m;do{ws();String k=string();need(':');if(m.containsKey(k))throw fail();m.put(k,value());}while(take(','));need('}');return m;}
            if(c=='['){p++;List<Object> a=new ArrayList<>();if(take(']'))return a;do{a.add(value());}while(take(','));need(']');return a;}
            for(String literal:new String[]{"true","false","null"})if(s.startsWith(literal,p)){p+=literal.length();return literal.equals("null")?null:Boolean.valueOf(literal);}
            int start=p;if(p<s.length()&&s.charAt(p)=='-')p++;
            if(p>=s.length())throw fail();
            if(s.charAt(p)=='0')p++;else{if(s.charAt(p)<'1'||s.charAt(p)>'9')throw fail();while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;}
            if(p<s.length()&&s.charAt(p)=='.'){p++;int q=p;while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;if(q==p)throw fail();}
            if(p<s.length()&&(s.charAt(p)=='e'||s.charAt(p)=='E')){p++;if(p<s.length()&&(s.charAt(p)=='+'||s.charAt(p)=='-'))p++;int q=p;while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;if(q==p)throw fail();}
            try{double d=Double.parseDouble(s.substring(start,p));if(!Double.isFinite(d))throw fail();return d;}catch(NumberFormatException ex){throw fail();}
        }finally{depth--;}}
        String string(){if(p>=s.length()||s.charAt(p++)!='"')throw fail();StringBuilder out=new StringBuilder();
            while(p<s.length()){char c=s.charAt(p++);if(c=='"')return out.toString();if(c<32)throw fail();
                if(c=='\\'){if(p>=s.length())throw fail();char e=s.charAt(p++);switch(e){case '"','\\','/'->out.append(e);case 'b'->out.append('\b');case 'f'->out.append('\f');case 'n'->out.append('\n');case 'r'->out.append('\r');case 't'->out.append('\t');case 'u'->{if(p+4>s.length())throw fail();try{out.append((char)Integer.parseInt(s.substring(p,p+4),16));}catch(NumberFormatException ex){throw fail();}p+=4;}default->throw fail();}}
                else out.append(c);
            }throw fail();}
    }
}
