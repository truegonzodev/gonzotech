final class HeatDynamicsTest {
    static void check(boolean v,String m){ReaCalcTest.check(v,m);}
    static void close(double a,double b,double eps,String m){ReaCalcTest.close(a,b,eps,m);}
    static HeatDynamics.State state(HeatDynamics.Parameters p){var s=new HeatDynamics.State();s.configure(p);return s;}
    static void run()throws Exception{
        double[] oldUseful={2.366365913106677,5.204146658002872,5.881956791566947,675.7576466466564,11.750029166354953,2588.9307096038347,18.798932091339065,6445.821480851574};
        double[] oldTw={100.06320565443403,109.460855500848,100.01266449423088,376.64515389952055,100.00232405667376,491.12332322118107,100.00180518395175,581.4908623188815};
        double[] oldH={.6608200297673051,.8634318597312638,.14293930800306778,.9936053885959317,.16604210730619526,.999907465637548,.18112732445608212,.9992590042276869};
        for(int i=0;i<8;i++){
            var doc=TutorialCatalog.load(16+i);var raw=ReaCalc.evaluate(doc.grid());var v=OperatingMetrics.calculate(raw,doc.loadedRods());
            close(v.usefulOutput(),oldUseful[i]*1.84,1e-7,"golden exact output gain "+i);close(v.waterTemperature(),oldTw[i],1e-7,"golden unchanged water "+i);close(v.htv(),oldH[i],1e-9,"golden unchanged Htv "+i);
            var unscaled=OperatingMetrics.water(v.power(),v.ltv(),v.waterUnits(),v.meanTemperature());close(v.pressure(),unscaled.pressure(),1e-12,"unchanged pressure");close(v.output(),unscaled.output()*1.84,1e-9,"exchange exact gain");
            var p=HeatDynamics.parameters(raw,v);var s=state(p);check(s.temperature()==20&&s.useful()==0&&s.exchange()==0,"cold start zero output");
            s.advance(p.tau()*Math.log(2));close(s.temperature(),20+(v.hotTemperature()-20)/2,1e-8,"half temperature rise");
            double factor=Math.pow(.5,1/OperatingMetrics.TEMP_EXPONENT);
            var half=OperatingMetrics.water(v.power()*factor,OperatingMetrics.scaledLeak(v.rawL(),v.ratio()*factor),v.waterUnits(),20+(v.meanTemperature()-20)/2);
            close(s.useful(),1.84*half.output()*OperatingMetrics.quality(half.temperature()),1e-8,"output follows equivalent thermal state");close(s.exchange(),1.84*half.output(),1e-8,"exchange follows equivalent thermal state");
            s.advance(p.tau()*30);close(s.useful(),v.usefulOutput(),1e-6,"plateau output");close(s.temperature(),v.hotTemperature(),1e-6,"unchanged core plateau");
        }
        var p=new HeatDynamics.Parameters(.88,100,10,2400,80,0,2,1,false);
        var one=state(p);one.advance(200);var many=state(p);for(int i=0;i<200;i++)many.advance(1);close(one.temperature(),many.temperature(),1e-9,"stable independent of timestep");
        var run=new HeatDynamics.Parameters(26,100,700,20+OperatingMetrics.TEMP_SCALE,4,25,2,1,true);
        one=state(run);many=state(run);double onset=4*Math.log(100)+20;one.advance(onset+5);for(int i=0;i<1000;i++)many.advance((onset+5)/1000);close(one.temperature(),many.temperature(),1e-7,"runaway independent of timestep");close(one.velocity,many.velocity,1e-8,"runaway velocity independent of timestep");
        var before=state(run);before.advance(onset);close(before.velocity,0,1e-10,"no acceleration before delay");before.advance(1);close(before.velocity,50,1e-8,"quadratic acceleration starts");
        var failing=state(run);failing.advance(1000000);check(failing.destroyed&&failing.temperature()==10000&&failing.useful()==0&&failing.exchange()==0,"failure stops production");check(failing.ticks>50&&failing.ticks<60,"explosive example about2.8seconds");double stopped=failing.ticks;failing.advance(50);close(failing.ticks,stopped,0,"failure stops time");
        var incremental=state(run);while(!incremental.destroyed)incremental.advance(.25);close(incremental.ticks,failing.ticks,1e-8,"failure time independent of step");
        failing.configure(p);check(failing.destroyed,"configuration edit cannot revive destruction");failing.reset();check(!failing.destroyed&&failing.temperature()==20&&failing.ticks==0,"explicit cold reset");
        var changed=state(p);changed.advance(80);double hot=changed.temperature();changed.configure(new HeatDynamics.Parameters(.4,100,2,800,120,0,1,.5,false));close(changed.temperature(),hot,0,"loading edits preserve temperature");changed.advance(20);close(changed.temperature(),hot,0,"cooling initial hold");changed.advance(40);check(changed.temperature()<hot,"hot core cools toward lower plateau");
        hot=changed.temperature();double output=changed.useful();changed.configure(new HeatDynamics.Parameters(0,100,0,20,100,0,0,0,false));close(changed.temperature(),hot,0,"unloading preserves heat");close(changed.useful(),output,0,"stored heat keeps last conversion");changed.advance(100);check(changed.useful()>0&&changed.useful()<output,"residual heat decays");
        var running=state(run);running.advance(onset+2);double speed=running.velocity;hot=running.temperature();running.configure(run);close(running.temperature(),hot,0,"runaway reconfigure keeps heat");close(running.velocity,speed,0,"runaway reconfigure cannot reset delay");
        running.configure(p);hot=running.temperature();running.advance(10);check(running.temperature()==hot&&running.velocity==0,"stable configuration stops acceleration before cooling");running.advance(60);check(running.temperature()<hot,"runaway heat then cools slowly");
        var critical=state(new HeatDynamics.Parameters(1,100,10,2858,100,.0001,1,.5,true));critical.advance(100*Math.log(100)+30);check(critical.velocity>0,"exact H1 has no true plateau");
        var doc=TutorialCatalog.load(0);var r=ReaCalc.evaluate(doc.grid());var bad=OperatingMetrics.calculate(r,6);check(bad.overheat(),"runaway fixture");var bp=HeatDynamics.parameters(r,bad);check(Double.isFinite(bp.usefulSlope())&&bp.referenceOnly(),"finite reference output during runaway");check(Double.isNaN(bad.hotTemperature())&&Double.isNaN(bad.usefulOutput()),"no false plateau during runaway");
        var larger=state(new HeatDynamics.Parameters(.88,200,10,2400,160,0,2,1,false));larger.advance(80);var smaller=state(p);smaller.advance(80);check(larger.temperature()<smaller.temperature(),"more inertia delays warmup");
        coolingTests();
        HeatOutputCurveTest.run();
    }
    static HeatDynamics.State hotState(double start,double target){
        var s=state(new HeatDynamics.Parameters(.8,124,1000,target,.1,0,2,1,false));s.base=start;s.configure(s.parameters);return s;
    }
    static void coolingTests(){
        var s=hotState(5000,2200);double arrival=s.coolingRemaining();check(arrival/20>25&&arrival/20<26,"5000 to2200 about25seconds");
        s.advance(20);close(s.temperature(),5000,0,"one second hold");s.advance(20);close(s.temperature(),4937.5,1e-9,"gentle first ramp second");
        s.advance(arrival-40);close(s.temperature(),2205,1e-7,"arrival within5degrees");close(s.coolingRemaining(),0,1e-6,"cooling countdown complete");
        s.advance(100000);close(s.temperature(),2200,1e-9,"no overshoot of loaded plateau");
        s=hotState(9000,20);arrival=s.coolingRemaining();check(arrival/20>49&&arrival/20<51,"9000 toambient about50seconds");s.advance(40);check(s.temperature()>8900,"no collapse after2seconds");s.advance(arrival-40);close(s.temperature(),25,1e-7,"nearambient50seconds");
        var one=hotState(9000,2200);var many=hotState(9000,2200);one.advance(800);for(int i=0;i<8000;i++)many.advance(.1);close(one.temperature(),many.temperature(),1e-7,"cooling independent of timestep");
        var partial=hotState(9000,2200);var unloaded=hotState(9000,20);
        unloaded.configure(new HeatDynamics.Parameters(0,4096,0,20,10000,0,0,0,false));partial.advance(400);unloaded.advance(400);close(partial.temperature(),unloaded.temperature(),1e-9,"bulk cooling independent of fuel and mass");
        var lowPower=hotState(5000,2200);var highPower=hotState(5000,2200);highPower.configure(new HeatDynamics.Parameters(.8,1,90000,2200,.001,0,2,1,false));
        lowPower.advance(400);highPower.advance(400);close(lowPower.temperature(),highPower.temperature(),1e-9,"cooling ignores heating power and tau");
        var edited=hotState(9000,2200);edited.advance(30);double age=edited.coolingAge,hot=edited.temperature();edited.configure(new HeatDynamics.Parameters(0,1,0,20,100,0,0,0,false));close(edited.coolingAge,age,0,"further unloading retains cooling clock");close(edited.temperature(),hot,0,"further unloading retains temperature");edited.advance(1);check(edited.temperature()<hot,"edits cannot rearm cooling hold");
        var warm=hotState(5000,2200);warm.advance(200);hot=warm.temperature();warm.configure(new HeatDynamics.Parameters(2,124,100,2858,1,1,2,1,true));warm.advance(10);close(warm.temperature(),hot,1e-9,"hot unstable reload cannot dump stored heat");warm.advance(40);check(warm.temperature()>hot,"hot unstable reload resumes runaway");
        var small=hotState(2202,2200);small.advance(100000);close(small.temperature(),2200,1e-9,"small gap converges without overshoot");
        var reheat=hotState(200,20);reheat.advance(60);hot=reheat.temperature();reheat.configure(new HeatDynamics.Parameters(.8,124,100,2200,100,0,2,1,false));reheat.advance(100);close(reheat.temperature(),2200+(hot-2200)*Math.exp(-1),1e-9,"reheating still uses original warmup law");
    }
}
