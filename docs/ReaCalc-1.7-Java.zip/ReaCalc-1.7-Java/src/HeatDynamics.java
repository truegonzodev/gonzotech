/** Game-time postprocessing. Never feeds into neutron transport or the water equilibrium. */
final class HeatDynamics {
    static final double AMBIENT=20,FAILURE=10000,TICKS_PER_SECOND=20,K=.01,DELAY=20,EPSILON=.0001;
    static final double RUN_GAIN=4/(K*OperatingMetrics.TEMP_SCALE);
    // Independent game cooling clock: 1 s hold, 2 s ramp, up to 250 C/s.
    static final double COOL_DELAY=20,COOL_RAMP=40,COOL_RATE=12.5,COOL_TAU=60,COOL_TOLERANCE=5;
    static double coolingClock(double age){
        double t=Math.max(0,age-COOL_DELAY);
        return t<COOL_RAMP?t*t/(2*COOL_RAMP):t-COOL_RAMP/2;
    }
    static double coolingClockInverse(double t){return COOL_DELAY+(t<COOL_RAMP/2?Math.sqrt(2*COOL_RAMP*t):t+COOL_RAMP/2);}
    static double coolGap(double gap,double dt){
        double threshold=COOL_RATE*COOL_TAU;
        if(gap>threshold){double linear=Math.min(dt,(gap-threshold)/COOL_RATE);gap-=COOL_RATE*linear;dt-=linear;}
        return gap*Math.exp(-dt/COOL_TAU);
    }
    record Parameters(double h,double mass,double sourcePower,double target,double tau,double acceleration,
                      double exchangeSlope,double usefulSlope,boolean referenceOnly,HeatOutputCurve outputCurve){
        // Simple linear fixtures for tests of the temperature integrator itself.
        Parameters(double h,double mass,double sourcePower,double target,double tau,double acceleration,double exchangeSlope,double usefulSlope,boolean referenceOnly){
            this(h,mass,sourcePower,target,tau,acceleration,exchangeSlope,usefulSlope,referenceOnly,null);
        }
    }
    static Parameters parameters(VolumeView.Result r,OperatingMetrics.Values v){
        int mass=0;var g=r.grid();for(int z=0;z<g.nz;z++)for(int y=0;y<g.ny;y++)for(int x=0;x<g.nx;x++)if(g.get(x,y,z)!=MatrixCoefficients.Material.EMPTY)mass++;
        double target=v.overheat()?AMBIENT+OperatingMetrics.TEMP_SCALE:v.hotTemperature();
        double tau=v.power()>0?Math.max(.001,K*Math.max(1,mass)*(target-AMBIENT)/v.power()):4*Math.pow(Math.max(1,mass),2./3);
        double a=v.overheat()?RUN_GAIN*v.power()/Math.max(1,mass)*(v.htv()-1+EPSILON):0;
        var ref=OperatingMetrics.outputReference(r,v);double delta=ref.temperature()-AMBIENT;
        return new Parameters(v.htv(),mass,v.power(),target,tau,a,delta>0?ref.exchange()/delta:0,delta>0?ref.useful()/delta:0,v.overheat(),new HeatOutputCurve(r));
    }
    static final class State {
        Parameters parameters;
        double ticks,base=AMBIENT,excess,velocity,hold=DELAY,exchangeSlope,usefulSlope,coolingAge=-1;
        boolean destroyed;
        HeatOutputCurve cachedCurve;double cachedTemperature=Double.NaN;
        HeatOutputCurve.Output cachedOutput=HeatOutputCurve.ZERO;
        void configure(Parameters next){
            boolean continuing=parameters!=null&&parameters.h>=1&&next.h>=1;
            double current=temperature();if(!continuing){base=current;excess=0;velocity=0;hold=DELAY;}
            // Reloading a hot stable core must not dump its heat through the fast warmup clock.
            if(!continuing&&next.h>=1&&base>next.target){excess=base-next.target;base=next.target;}
            parameters=next;
            if(next.h<1&&current>next.target){if(coolingAge<0)coolingAge=0;}else coolingAge=-1;
            // Only the analytical linear fixtures use these slopes; the app uses the fixed geometry curve.
            if(next.sourcePower>0||current<=AMBIENT+1e-9){exchangeSlope=next.exchangeSlope;usefulSlope=next.usefulSlope;}
        }
        void reset(){ticks=0;base=AMBIENT;excess=0;velocity=0;hold=DELAY;coolingAge=-1;destroyed=false;if(parameters!=null){exchangeSlope=parameters.exchangeSlope;usefulSlope=parameters.usefulSlope;}}
        boolean cooling(){return !destroyed&&parameters!=null&&parameters.h<1&&temperature()>parameters.target;}
        double coolingRemaining(){
            if(!cooling())return 0;double gap=temperature()-parameters.target;if(gap<=COOL_TOLERANCE)return 0;
            double threshold=COOL_RATE*COOL_TAU;
            double work=Math.max(0,(gap-threshold)/COOL_RATE)+COOL_TAU*Math.log(Math.min(gap,threshold)/COOL_TOLERANCE);
            double age=Math.max(0,coolingAge);return Math.max(0,coolingClockInverse(coolingClock(age)+work)-age);
        }
        double temperature(){return base+excess;}
        HeatOutputCurve.Output output(){
            if(destroyed||parameters==null)return HeatOutputCurve.ZERO;
            var curve=parameters.outputCurve;double t=temperature();
            if(curve==null)return new HeatOutputCurve.Output(Math.max(0,t-AMBIENT)*exchangeSlope,Math.max(0,t-AMBIENT)*usefulSlope);
            if(curve!=cachedCurve||t!=cachedTemperature){cachedCurve=curve;cachedTemperature=t;cachedOutput=curve.at(t);}
            return cachedOutput;
        }
        double exchange(){return output().exchange();}
        double useful(){return output().useful();}
        String phase(){if(destroyed)return "Разрушен";if(parameters==null)return "Нет расчёта";
            if(cooling()&&temperature()-parameters.target>COOL_TOLERANCE)return coolingAge<COOL_DELAY?"Рост остановлен · задержка охлаждения":"Медленное остывание";
            if(parameters.sourcePower==0)return temperature()>AMBIENT+.01?"Почти остыл":"Холодный";
            if(parameters.h<1)return Math.abs(temperature()-parameters.target)<=Math.max(.01,(parameters.target-AMBIENT)*.01)?"Около плато":temperature()>parameters.target?"Остывание к плато":"Нагрев";
            if(velocity>0)return "Ускоряющийся разгон";return temperature()>=AMBIENT+.99*(parameters.target-AMBIENT)?"Задержка перед разгоном":"Нагрев · Htv ≥ 1";
        }
        private double warmTime(){double threshold=AMBIENT+.99*(parameters.target-AMBIENT);return base<threshold?parameters.tau*Math.log((parameters.target-base)/(parameters.target-threshold)):0;}
        private double predicted(double dt){
            double nextBase=parameters.target+(base-parameters.target)*Math.exp(-dt/parameters.tau);
            if(parameters.h<1)return nextBase;
            double active=Math.max(0,dt-warmTime()-hold);return nextBase+excess+velocity*active+parameters.acceleration*active*active;
        }
        void advance(double dt){
            if(!Double.isFinite(dt)||dt<0)throw new IllegalArgumentException("Некорректный шаг времени");
            if(parameters==null||destroyed||dt==0)return;
            if(cooling()){
                coolingAge=Math.max(0,coolingAge);double elapsed=coolingClock(coolingAge+dt)-coolingClock(coolingAge);
                base=parameters.target+coolGap(base-parameters.target,elapsed);coolingAge+=dt;ticks+=dt;return;
            }
            coolingAge=-1;
            boolean fails=predicted(dt)>=FAILURE;
            if(fails){double lo=0,hi=dt;for(int i=0;i<60;i++){double mid=(lo+hi)/2;if(predicted(mid)<FAILURE)lo=mid;else hi=mid;}dt=(lo+hi)/2;}
            if(parameters.h>=1){double afterWarm=Math.max(0,dt-warmTime()),active=Math.max(0,afterWarm-hold);hold=Math.max(0,hold-afterWarm);excess+=velocity*active+parameters.acceleration*active*active;velocity+=2*parameters.acceleration*active;}
            base=parameters.target+(base-parameters.target)*Math.exp(-dt/parameters.tau);ticks+=dt;
            if(fails){base=FAILURE;excess=0;destroyed=true;}
        }
    }
}
