import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.*;

final class MetricsPanel extends ReaCalc.ScrollPanel {
    final Map<String,JLabel> values=new LinkedHashMap<>();
    MetricsPanel(){setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));setBackground(ReaCalc.PANEL);setBorder(new EmptyBorder(14,12,14,12));
        group("ЗАГРУЖЕННАЯ КОНСТРУКЦИЯ");
        metric("target","Целевой rawH","rawH* = 0.99999 × N / R. Сырой H, при котором текущая загрузка даст Htv=0.99999. Это целевое значение под порогом, а не математический максимум. При R=0 цель не определена.");
        metric("delta","ΔH до цели","ΔH = целевой rawH − текущий rawH. Плюс: сырой H можно увеличить; минус: его нужно уменьшить для достижения Htv=0.99999 при этой загрузке.");
        metric("ltv","Ltv · с загрузкой","Пиковая утечка при равномерной загрузке r=R/N: Ltv=r×Lraw/(1−Lraw+r×Lraw). Показано 100×Ltv процентов шкалы, не доля всех частиц. При R=0 утечка равна нулю.");
        metric("meanH","Средний Htv","Среднее локальной нагрузки h_i=u_i/Ubudget × R/N по всем непустым клеткам, с одинаковым весом клеток. В отличие от Htv, это не максимум.");
        metric("hot","T горячей точки","Температура самой горячей точки конструкции на плато. T(h)=20+2838.43365245×h^1.37798040865 °C. Сохранена прежняя игровая шкала: h=0.77 → 2000 °C, h=0.88 → 2400 °C. При Htv≥1 плато отсутствует: NaN / перегрев.");
        metric("fuelT","T топлива · max","Та же игровая шкала, но максимум берётся только по клеткам-чехлам. Это оценка температуры чехла с топливом; микроструктура и температура отдельных таблеток не моделируются. Общая горячая точка может находиться в другом материале.");
        metric("meanT","T реактора · средняя","Арифметическое среднее температур всех непустых клеток после применения T(h_i) к каждой клетке. Это не T от среднего H и не среднее, взвешенное по теплоёмкости. При глобальном Htv≥1 плато отсутствует и здесь.");
        group("ТЕОРИЯ · ИГРОВОЙ ТЕПЛООБМЕННИК");
        metric("qdry","q сухой · сумма","Σq_i из исходного решателя при единичном источнике в каждом чехле. Суммарная оценка полезного пути сигнала по объёму. Она безразмерная; это не температура и не физическая энергия.");
        metric("power","P нагрев","P=100 × (R/N) × Σq_i. Коэффициент 100 задаёт игровые единицы тепла за тик. При нулевой загрузке P=0. Во время перегрева производство остаётся определено, хотя стационарные температуры уже не показываются.");
        metric("water","Вода · полный бак","Отдельный запас теплоносителя, не число водяных блоков. Выбрано правило W=min(X,Y,Z), бак всегда заполнен: 16³ → 16, 9³ → 9. Для прямоугольной сборки ёмкость ограничивает самая короткая ось.");
        metric("tw","T воды · плато","Экспериментальное стационарное равновесие: вход=min(P×(1−Ltv), 0.6W×(Tсред−Tw)); выход=0.15W×(Tw−20)×Fдавления. Ниже 90 °C — низкая полезная температура; 100…300 °C — целевой игровой диапазон; выше 300 °C — горячая вода, но это ещё не перегрев активной зоны. При Htv≥1: NaN / перегрев. При нулевой загрузке: 20 °C.");
        metric("pressure","Давление воды","Условный индекс давления p=1+((Tw−20)/100)². При 20 °C p=1. Это НЕ бары и не термодинамическая таблица пара. При отсутствии плато температура и давление не определяются.");
        metric("feedback","Обратная связь p","F=1+0.12×(p−1). В игровом теплообменнике давление усиливает отвод тепла, поэтому подавляет равновесный рост Tw. Это условная отрицательная обратная связь, а не утверждение, что физическое давление охлаждает воду. Время нагрева здесь не моделируется.");
        metric("output","P теплообмен · плато","1.84 × прежний теплообмен. Множитель переводит расчёт в выходные игровые единицы тепла и применяется ПОСЛЕ водяного равновесия. Температуры, давление, Htv и Pнагрев не меняются. Текущая мощность по температуре показана во вкладке нагрева. При перегреве плато не определено: NaN.");
        metric("useful","P полезный · плато","Pполезный=1.84 × прежний полезный выход = новый Pтеплообмен×clamp((Tw−90)/110,0,1). Это игровой штраф за низкую температуру воды: при Tw≤90 полезный выход нулевой; от 90 до 200 растёт; от 200 коэффициент равен 1. Неиспользованное тепло остаётся отведённым, но не засчитывается как полезный выход. При перегреве: NaN.");
        metric("efficiency","Доля после потерь","Pполезный / (1.84 × Pнагрев) × 100%. Единицы источника и выхода согласованы множителем 1.84; доля потерь осталась прежней. Учитывает способность водяного контура принять тепло и его температуру. При нулевой мощности принято 0%. Это отдельный показатель от рейтинга S.");
        metric("regime","Режим","Нет топлива: R=0. Неэффективно: Tw<90 °C. Переход: 90…100 °C. Рабочий диапазон: 100…300 °C. Горячая вода: Tw>300 °C при Htv<1. Перегрев: Htv≥1, стационарных температур нет.");
    }
    static String tip(String text){return "<html><div style='width:360px'>"+text+"</div></html>";}
    void group(String name){if(!values.isEmpty())add(Box.createVerticalStrut(18));JLabel t=ReaCalc.label(name,true);t.setAlignmentX(LEFT_ALIGNMENT);add(t);add(Box.createVerticalStrut(8));}
    void metric(String key,String name,String explanation){JPanel row=new JPanel(new BorderLayout(8,0));row.setAlignmentX(LEFT_ALIGNMENT);row.setBorder(new EmptyBorder(7,0,7,0));row.setMaximumSize(new Dimension(Integer.MAX_VALUE,40));
        JLabel label=new JLabel(name),value=new JLabel("—");label.setFont(new Font("Segoe UI",Font.PLAIN,12));value.setFont(new Font("Consolas",Font.BOLD,14));value.setForeground(ReaCalc.ACCENT);value.setHorizontalAlignment(SwingConstants.RIGHT);String tt=tip(explanation);row.setToolTipText(tt);label.setToolTipText(tt);value.setToolTipText(tt);row.add(label,BorderLayout.WEST);row.add(value,BorderLayout.EAST);values.put(key,value);add(row);}
    static String number(double d,int digits){return Double.isFinite(d)?String.format(Locale.ROOT,"%."+digits+"f",d):"—";}
    void set(String key,String text){values.get(key).setText(text);}
    void clear(){values.values().forEach(l->{l.setText("…");l.setForeground(ReaCalc.ACCENT);});}
    void update(OperatingMetrics.Values v){
        set("target",number(v.targetRawH(),5));set("delta",Double.isFinite(v.deltaRawH())?String.format(Locale.ROOT,"%+.5f",v.deltaRawH()):"—");set("ltv",number(v.ltv()*100,3)+" %");set("meanH",number(v.meanH(),5));
        set("hot",temp(v.hotTemperature()));set("fuelT",temp(v.fuelTemperature()));set("meanT",temp(v.meanTemperature()));
        set("qdry",number(v.qDry(),4));set("power",number(v.power(),2)+" ед/тик");set("water",v.waterUnits()+" ед.");set("tw",temp(v.waterTemperature()));
        set("pressure",Double.isFinite(v.pressure())?number(v.pressure(),3)+" усл.":"NaN · перегрев");set("feedback",Double.isFinite(v.pressureFeedback())?"× "+number(v.pressureFeedback(),3):"NaN");
        set("output",Double.isFinite(v.output())?number(v.output(),2)+" ед/тик":"NaN · перегрев");set("useful",Double.isFinite(v.usefulOutput())?number(v.usefulOutput(),2)+" ед/тик":"NaN · перегрев");set("efficiency",v.overheat()?"NaN":number(v.power()>0?100*v.usefulOutput()/(OperatingMetrics.OUTPUT_GAIN*v.power()):0,1)+" %");
        String regime=v.overheat()?"Перегрев":v.rods()==0?"Нет топлива":v.waterTemperature()<90?"Неэффективно":v.waterTemperature()<100?"Переход":v.waterTemperature()<=300?"Рабочий диапазон":"Горячая вода";
        set("regime",regime);values.get("regime").setForeground(v.overheat()||v.waterTemperature()>300?new Color(255,120,130):v.waterTemperature()<100?new Color(245,192,101):ReaCalc.ACCENT);
    }
    static String temp(double t){return Double.isFinite(t)?number(t,1)+" °C":"NaN · перегрев";}
}

