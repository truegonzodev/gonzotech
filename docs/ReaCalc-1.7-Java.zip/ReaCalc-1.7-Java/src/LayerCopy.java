/** Text clipboard format shared across application instances; only materials are copied. */
final class LayerCopy {
    static final String PREFIX="REACALC_LAYER_V1\n";
    static String encode(MatrixCoefficients.Grid g,int z){
        if(z<0||z>=g.nz)throw new IllegalArgumentException("Неизвестный слой.");
        var layer=new MatrixCoefficients.Grid(g.nx,g.ny,1,MatrixCoefficients.Material.EMPTY);
        for(int y=0;y<g.ny;y++)for(int x=0;x<g.nx;x++)layer.set(x,y,0,g.get(x,y,z));
        return PREFIX+ReactorIO.encode(layer);
    }
    static MatrixCoefficients.Grid paste(MatrixCoefficients.Grid target,int z,String text){
        if(text==null||!text.startsWith(PREFIX))throw new IllegalArgumentException("В буфере нет слоя ReaCalc. Сначала нажмите Ctrl+C над редактором.");
        if(z<0||z>=target.nz)throw new IllegalArgumentException("Неизвестный слой.");
        var layer=ReactorIO.decode(text.substring(PREFIX.length()));
        if(layer.nz!=1||layer.nx!=target.nx||layer.ny!=target.ny)throw new IllegalArgumentException("Размер скопированного слоя должен совпадать: "+target.nx+" × "+target.ny+". Вставка отменена.");
        var out=target.copy();for(int y=0;y<target.ny;y++)for(int x=0;x<target.nx;x++)out.set(x,y,z,layer.get(x,y,0));return out;
    }
}
