/** Exact linear loading plus explicitly fictional equilibrium / UI temperature rules. */
final class OperatingMetrics {
    static final double TARGET_H=.99999, AMBIENT=20, POWER_SCALE=100, WATER_REMOVAL=.15;
    static final double TEMP_SCALE=2838.43365245,TEMP_EXPONENT=1.37798040865;
    static final double OUTPUT_GAIN=1.84;
    record Water(double temperature,double pressure,double feedback,double output){}
    record Values(int sleeves,int rods,double ratio,double rawH,double rawL,double htv,double ltv,
                  double score,double targetRawH,double deltaRawH,double qDry,double power,int waterUnits,
                  double meanH,double hotTemperature,double fuelTemperature,double meanTemperature,
                  double waterTemperature,double pressure,double pressureFeedback,double output,double usefulOutput,boolean overheat){}
    static double temperature(double h){return h>=1?Double.NaN:AMBIENT+TEMP_SCALE*Math.pow(Math.max(0,h),TEMP_EXPONENT);}
    static double scaledLeak(double rawL,double ratio){return ratio==0?0:ratio*rawL/(1-rawL+ratio*rawL);}
    static Values calculate(VolumeView.Result result,int rods){
        var g=result.grid();ReactorIO.validateRods(g,rods);int n=result.fuels();double ratio=n==0?0:(double)rods/n;
        double htv=result.h()*ratio,ltv=scaledLeak(result.l(),ratio);boolean overheat=htv>=1;
        double target=ratio==0?Double.NaN:TARGET_H/ratio,delta=target-result.h();
        double q=0,hsum=0,tsum=0,fuelPeak=0;int occupied=0;
        for(int z=0;z<g.nz;z++)for(int y=0;y<g.ny;y++)for(int x=0;x<g.nx;x++){
            int i=g.index(x,y,z);q+=result.raw().heatProduction()[i];var m=g.get(x,y,z);
            double hi=result.raw().load()[i]/ReaCalc.HEAT_BUDGET*ratio;
            if(m!=MatrixCoefficients.Material.EMPTY){occupied++;hsum+=hi;if(!overheat)tsum+=temperature(hi);}
            if(m==MatrixCoefficients.Material.FUEL)fuelPeak=Math.max(fuelPeak,hi);
        }
        double meanH=occupied==0?0:hsum/occupied;
        double meanT=overheat?Double.NaN:occupied==0?AMBIENT:tsum/occupied;
        double power=POWER_SCALE*ratio*q;int water=Math.min(g.nx,Math.min(g.ny,g.nz));
        Water w=overheat?new Water(Double.NaN,Double.NaN,Double.NaN,Double.NaN):water(power,ltv,water,meanT);
        double score=overheat?Double.NaN:n*Math.pow(htv,1.5)*(1-ltv);
        return new Values(n,rods,ratio,result.h(),result.l(),htv,ltv,score,target,delta,q,power,water,meanH,
                overheat?Double.NaN:temperature(htv),overheat?Double.NaN:temperature(fuelPeak),meanT,
                w.temperature,w.pressure,w.feedback,OUTPUT_GAIN*w.output,OUTPUT_GAIN*w.output*quality(w.temperature),overheat);
    }
    record OutputReference(double temperature,double exchange,double useful){}
    // Reference slopes for a runaway only; this does not claim a steady state at Htv>=1.
    static OutputReference outputReference(VolumeView.Result result,Values v){
        if(!v.overheat())return new OutputReference(v.hotTemperature(),v.output(),v.usefulOutput());
        double ratio=TARGET_H/result.h(),sum=0;int count=0;var grid=result.grid();
        for(int z=0;z<grid.nz;z++)for(int y=0;y<grid.ny;y++)for(int x=0;x<grid.nx;x++)if(grid.get(x,y,z)!=MatrixCoefficients.Material.EMPTY){
            sum+=temperature(result.raw().load()[grid.index(x,y,z)]/ReaCalc.HEAT_BUDGET*ratio);count++;
        }
        Water w=water(POWER_SCALE*ratio*v.qDry(),scaledLeak(result.l(),ratio),v.waterUnits(),count==0?AMBIENT:sum/count);
        return new OutputReference(temperature(TARGET_H),OUTPUT_GAIN*w.output,OUTPUT_GAIN*w.output*quality(w.temperature));
    }
    static double quality(double temperature){return Double.isFinite(temperature)?Math.max(0,Math.min(1,(temperature-90)/110)):Double.NaN;}
    // Pressure is a game feedback index, not bar or a steam-table calculation.
    static double pressure(double temperature){return 1+Math.pow(Math.max(0,temperature-AMBIENT)/100,2);}
    static double feedback(double pressure){return 1+.12*(pressure-1);}
    static Water water(double power,double leak,int units,double meanTemperature){
        if(!Double.isFinite(meanTemperature))return new Water(Double.NaN,Double.NaN,Double.NaN,Double.NaN);
        double available=power*(1-leak),lo=AMBIENT,hi=Math.max(AMBIENT,meanTemperature);
        // Supply = min(available generated power, finite heat exchanger transfer).
        // Removal grows with pressure. Both sides are monotone, yielding one equilibrium.
        for(int step=0;step<80;step++){
            double t=(lo+hi)*.5;double supply=Math.min(available,.6*units*Math.max(0,meanTemperature-t));
            double removal=WATER_REMOVAL*units*(t-AMBIENT)*feedback(pressure(t));
            if(removal> supply)hi=t;else lo=t;
        }
        double t=(lo+hi)*.5,p=pressure(t),f=feedback(p),output=WATER_REMOVAL*units*(t-AMBIENT)*f;
        return new Water(t,p,f,output);
    }
}
