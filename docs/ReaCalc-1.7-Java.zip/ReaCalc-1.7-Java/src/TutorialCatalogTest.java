final class TutorialCatalogTest {
    static void run()throws Exception{
        ReaCalcTest.check(TutorialCatalog.ENTRIES.size()==24,"15 sizes plus working 188 plus 8 extremes");
        for(int i=0;i<TutorialCatalog.ENTRIES.size();i++){
            var doc=TutorialCatalog.load(i);var g=doc.grid();int n=i<15?i+2:i==15?16:new int[]{2,5,10,16}[(i-16)/2];
            ReaCalcTest.check(g.nx==n&&g.ny==n&&g.nz==n,"tutorial dimensions");
            var v=OperatingMetrics.calculate(ReaCalc.evaluate(g),doc.loadedRods());
            ReaCalcTest.check(doc.loadedRods()>0&&!v.overheat()&&v.htv()<1,"loaded stable tutorial");
            boolean strong=i>=16&&(i-16)%2==1;
            ReaCalcTest.check(v.waterTemperature()>=100&&(strong||v.waterTemperature()<=300)&&v.usefulOutput()>0,"tutorial temperature criteria and output");
            var saved=ReactorIO.decodeDocument(ReactorIO.encodeDocument(g,doc.loadedRods()));ReaCalcTest.check(saved.loadedRods()==doc.loadedRods(),"tutorial retains loading");
            var exported=SchematicIOTest.read(SchematicIO.encode(g,doc.loadedRods(),"tutorial"));var states=SchematicIOTest.states(exported);
            for(int y=0;y<n;y++)for(int z=0;z<n;z++)for(int x=0;x<n;x++)if(!states[x+n*(z+n*y)].equals(SchematicIO.block(g.get(x,y,z))))throw new AssertionError("Tutorial export mismatch");
            ReaCalcTest.check(true,"all tutorial blocks exported in correct positions");
            if(i==15){ReaCalcTest.check(v.sleeves()==188&&doc.loadedRods()==18,"working188 full loading");ReaCalcTest.close(v.rawH(),10.44,.00001,"working188 raw target");ReaCalcTest.check(v.usefulOutput()/(OperatingMetrics.OUTPUT_GAIN*v.power())>.9,"working188 useful output above90percent");}
            if(i>=16){
                if(strong){var weak=TutorialCatalog.load(i-1);var w=OperatingMetrics.calculate(ReaCalc.evaluate(weak.grid()),weak.loadedRods());ReaCalcTest.check(v.usefulOutput()>w.usefulOutput(),"strong produces more than weak");}
                else {double lowerBound=OperatingMetrics.OUTPUT_GAIN*.15*n*80*(1+.12*.64)*(10./110);ReaCalcTest.check(v.usefulOutput()>=lowerBound&&v.usefulOutput()<lowerBound*1.01,"weak is within 1percent of working lower bound");}
            }
        }
    }
}

