import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.*;

/** A live timeline driven by HeatDynamics, separate from the unchanged dry renderer. */
final class HeatPanel extends JPanel {
    final HeatDynamics.State state=new HeatDynamics.State();
    record Point(double ticks,double temperature,double exchange,double useful){}
    final ArrayList<Point> history=new ArrayList<>();
    final JLabel temperature=new JLabel(),power=new JLabel(),exchange=new JLabel(),time=new JLabel(),phase=new JLabel(),reference=new JLabel();
    final JButton start=ReaCalc.button("Пуск",this::toggle),reset=ReaCalc.button("Холодный запуск",this::reset),step=ReaCalc.button("+20 тиков",()->advance(20));
    final JComboBox<String> speed=new JComboBox<>(new String[]{"×1","×5","×20","×100"});
    final Chart chart=new Chart();
    final javax.swing.Timer timer;
    long lastNanos;boolean ready;
    HeatPanel(){
        super(new BorderLayout(8,10));setBackground(ReaCalc.BG);setBorder(new EmptyBorder(12,12,12,12));
        JPanel top=new JPanel(new BorderLayout(0,8));top.setOpaque(false);
        JPanel controls=new JPanel(new FlowLayout(FlowLayout.LEFT,6,0));controls.setOpaque(false);controls.add(start);controls.add(reset);controls.add(step);controls.add(new JLabel("Скорость:"));controls.add(speed);top.add(controls,BorderLayout.NORTH);
        start.setToolTipText(MetricsPanel.tip("Запуск/пауза времени. При скорости ×1 за секунду проходят 20 игровых тиков. Расчёт нейтронного поля не запускается на каждом тике."));
        reset.setToolTipText(MetricsPanel.tip("Явно сбрасывает время, температуру к 20 °C и историю графика. Изменение загрузки сохраняет текущую температуру. Открытие другого проекта начинает холодный запуск."));
        step.setToolTipText(MetricsPanel.tip("Продвинуть расчёт ровно на 20 тиков. Шаг остановится раньше при достижении температуры разрушения 10 000 °C."));
        speed.setToolTipText(MetricsPanel.tip("Меняет только скорость воспроизведения времени; формулы, мощность и температурные пределы сохраняются."));
        JPanel readings=new JPanel(new GridLayout(2,2,10,5));readings.setOpaque(false);
        for(JLabel label:new JLabel[]{temperature,power,exchange,time}){label.setForeground(ReaCalc.TEXT);label.setFont(new Font("Consolas",Font.BOLD,15));readings.add(label);}top.add(readings,BorderLayout.CENTER);
        temperature.setToolTipText(MetricsPanel.tip("Текущая температура самой горячей точки активной зоны, T(t). Температуры плато справа остаются прежними. При Htv≥1 текущая температура определена, хотя стационарное плато отсутствует."));
        power.setToolTipText(MetricsPanel.tip("Pполезное = F(текущая температура, конструкция). Одна и та же температура даёт один и тот же выход при любом числе ТВЭЛов, включая ноль. Общая кривая нелинейна и совпадает с прежними мощностями на всех стабильных плато. При холодном состоянии и после разрушения выход нулевой. Переключение загрузки не меняет коэффициент мощности."));
        exchange.setToolTipText(MetricsPanel.tip("Pтеплообмена = G(текущая температура, конструкция). По температуре восстанавливается эквивалентная тепловая нагрузка и применяется прежняя формула теплообмена ×1.84. Это температурная кривая, а не фактическое число ТВЭЛов. Выше 2858.4 °C — непрерывное линейное продолжение. Вода и давление справа остаются оценками плато."));
        time.setToolTipText(MetricsPanel.tip("Пройденное игровое время. 20 тиков = 1 секунда; реальное время зависит от выбранной скорости."));
        add(top,BorderLayout.NORTH);add(chart,BorderLayout.CENTER);
        JPanel bottom=new JPanel(new GridLayout(2,1,0,5));bottom.setOpaque(false);phase.setForeground(ReaCalc.ACCENT);reference.setForeground(ReaCalc.MUTED);reference.setFont(new Font("Segoe UI",Font.PLAIN,11));bottom.add(phase);bottom.add(reference);add(bottom,BorderLayout.SOUTH);
        timer=new javax.swing.Timer(50,e->{long now=System.nanoTime();double dt=(now-lastNanos)/1e9*20*new int[]{1,5,20,100}[speed.getSelectedIndex()];lastNanos=now;advance(dt);});
        phase.setToolTipText(MetricsPanel.tip("Нагрев и разгон сохранены. При переходе к стабильной загрузке ниже текущей температуры: 1 с без снижения, 2 с плавного начала охлаждения, далее до 250 °C/с с замедлением возле нового плато. Скорость остывания не зависит от ТВЭЛов и массы. Загрузка задаёт только нижнее плато. Без топлива нижняя температура 20 °C. Повторные правки во время охлаждения не перезапускают задержку. При Htv≥1 разгон продолжается; при 10 000 °C — разрушение."));
        refresh();
    }
    void configure(VolumeView.Result r,OperatingMetrics.Values v){state.configure(HeatDynamics.parameters(r,v));ready=true;record();refresh();}
    void pending(){ready=false;pause();refresh();}
    void newProject(){pause();state.parameters=null;state.reset();ready=false;history.clear();refresh();}
    void reset(){pause();state.reset();history.clear();record();refresh();}
    void toggle(){if(timer.isRunning())pause();else if(ready&&!state.destroyed){lastNanos=System.nanoTime();timer.start();start.setText("Пауза");}}
    void pause(){if(timer!=null)timer.stop();start.setText("Пуск");}
    void advance(double ticks){
        if(!ready||state.destroyed)return;
        int samples=Math.max(1,Math.min(400,(int)Math.ceil(ticks/Math.max(.01,state.parameters.tau()/25))));
        for(int i=0;i<samples&&!state.destroyed;i++){state.advance(ticks/samples);record();}
        if(state.destroyed)pause();refresh();
    }
    void record(){history.add(new Point(state.ticks,state.temperature(),state.exchange(),state.useful()));if(history.size()>2048){ArrayList<Point> reduced=new ArrayList<>();for(int i=0;i<history.size()-1;i+=2)reduced.add(history.get(i));reduced.add(history.getLast());history.clear();history.addAll(reduced);}}
    void refresh(){
        temperature.setText("T сейчас: "+MetricsPanel.number(state.temperature(),1)+" °C");power.setText("P полезное: "+MetricsPanel.number(state.useful(),2)+" ед/тик");
        exchange.setText("P теплообмен: "+MetricsPanel.number(state.exchange(),2)+" ед/тик");time.setText("t: "+MetricsPanel.number(state.ticks,1)+" т · "+MetricsPanel.number(state.ticks/20,2)+" с");
        start.setEnabled(ready&&!state.destroyed);step.setEnabled(ready&&!state.destroyed);reset.setEnabled(state.parameters!=null);
        var p=state.parameters;phase.setText(!ready?"Ожидание расчёта конструкции":state.phase());phase.setForeground(state.destroyed||p!=null&&p.h()>=1?new Color(255,120,130):ReaCalc.ACCENT);
        String note=p==null?"Температуры воды и плато — в правой панели.":p.referenceOnly()?"Разгон · выработка по общей кривой температуры; плато отсутствует.":"C = "+MetricsPanel.number(p.mass(),0)+" блоков · τ = "+MetricsPanel.number(p.tau(),2)+" т · t95 = "+MetricsPanel.number(Math.log(20)*p.tau(),1)+" т";
        if(state.cooling())note="Остывание до "+MetricsPanel.number(p.target(),1)+" °C · осталось ≈ "+MetricsPanel.number(state.coolingRemaining()/20,1)+" с (до +5 °C) · до 250 °C/с";
        reference.setText(note);reference.setToolTipText(MetricsPanel.tip(note+" Температуры воды и давление справа — исходный стационарный расчёт, множитель 1.84 их не изменяет. Временная история не записывается в .reacalc."));chart.repaint();
    }
    void shutdown(){pause();}
    final class Chart extends JPanel {
        Chart(){setOpaque(false);setPreferredSize(new Dimension(640,380));setToolTipText(MetricsPanel.tip("Верхний график: текущая температура активной зоны. Нижний: выходной теплообмен и полезная мощность — непрерывные функции температуры для этой конструкции. Их форма может отличаться от температурной: связь нелинейна. Переключение ТВЭЛов при неизменной температуре не создаёт ступеней мощности."));}
        protected void paintComponent(Graphics source){super.paintComponent(source);Graphics2D g=(Graphics2D)source.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            int total=getHeight(),gap=28,pane=(total-gap)/2;double end=Math.max(20,state.ticks),maxT=20,maxP=0;
            for(Point p:history){maxT=Math.max(maxT,p.temperature);maxP=Math.max(maxP,p.exchange);}
            if(state.parameters!=null){maxT=Math.max(maxT,Math.min(HeatDynamics.FAILURE,state.parameters.target()));var curve=state.parameters.outputCurve();maxP=Math.max(maxP,curve!=null?curve.at(state.parameters.target()).exchange():state.parameters.exchangeSlope()*(state.parameters.target()-20));}
            drawPlot(g,0,pane,"Температура активной зоны, °C",end,Math.max(100,maxT*1.05),true);
            drawPlot(g,pane+gap,pane,"Выход, ед/тик · бирюзовый: полезное · жёлтый: теплообмен",end,Math.max(1,maxP*1.05),false);g.dispose();
        }
        void drawPlot(Graphics2D g,int top,int height,String title,double end,double max,boolean heat){
            int left=76,right=getWidth()-18,yt=top+24,yb=top+height-29;if(right<=left||yb<=yt)return;
            g.setFont(new Font("Segoe UI",Font.PLAIN,12));g.setColor(ReaCalc.TEXT);g.drawString(title,8,top+14);
            for(int j=0;j<=4;j++){int y=yb-(yb-yt)*j/4;g.setColor(new Color(46,55,74));g.drawLine(left,y,right,y);g.setColor(ReaCalc.MUTED);String label=String.format(Locale.ROOT,"%.0f",max*j/4);g.drawString(label,left-8-g.getFontMetrics().stringWidth(label),y+4);}
            for(int j=0;j<=3;j++){int x=left+(right-left)*j/3;String label=String.format(Locale.ROOT,"%.1f с",end/20*j/3);g.setColor(ReaCalc.MUTED);g.drawString(label,Math.max(left,Math.min(right-g.getFontMetrics().stringWidth(label),x-g.getFontMetrics().stringWidth(label)/2)),yb+20);}
            Shape oldClip=g.getClip();g.clipRect(left,yt,right-left+1,yb-yt+1);
            for(int series=0;series<(heat?1:2);series++){
                g.setColor(heat||series==1?ReaCalc.ACCENT:new Color(241,189,102));g.setStroke(new BasicStroke(heat||series==1?2.5f:1.5f));
                Point prev=null;for(Point p:history){if(prev!=null){double v=heat?p.temperature:series==0?p.exchange:p.useful,pv=heat?prev.temperature:series==0?prev.exchange:prev.useful;g.drawLine(left+(int)((right-left)*prev.ticks/end),yb-(int)((yb-yt)*pv/max),left+(int)((right-left)*p.ticks/end),yb-(int)((yb-yt)*v/max));}prev=p;}
            }g.setClip(oldClip);g.setStroke(new BasicStroke(1));
        }
    }
}

