final class OperatingMetricsTest {
    static void check(boolean v,String s){ReaCalcTest.check(v,s);}
    static void close(double a,double b,double eps,String s){ReaCalcTest.close(a,b,eps,s);}
    static void run()throws Exception{
        close(OperatingMetrics.temperature(.77),2000,1e-6,"temperature 0.77");close(OperatingMetrics.temperature(.88),2400,1e-6,"temperature 0.88");
        check(Double.isNaN(OperatingMetrics.temperature(1)),"no plateau at threshold");
        var dry=ReaCalc.evaluate(ReaCalc.resource188());var full=OperatingMetrics.calculate(dry,18);
        close(full.htv(),dry.h()*18/188,1e-12,"188 loaded H");close(full.targetRawH(),.99999*188/18,1e-12,"188 target H");close(full.deltaRawH(),full.targetRawH()-dry.h(),1e-12,"delta sign");
        close(full.qDry(),java.util.Arrays.stream(dry.raw().heatProduction()).sum(),1e-10,"total q");close(full.power(),100*18./188*full.qDry(),1e-10,"loaded power");
        check(full.waterUnits()==16&&full.meanTemperature()<=full.hotTemperature(),"water capacity and mean bounds");check(full.fuelTemperature()<=full.hotTemperature(),"fuel temperature bounded by global hot spot");
        var rules=new MatrixCoefficients.Rules(18./188,.05,.15,.05,1,2000,1e-10);var actual=MatrixCoefficients.analyze(dry.grid(),rules);
        close(actual.peakLoad()/ReaCalc.HEAT_BUDGET,full.htv(),1e-9,"linear H matches full loaded solve");close(actual.peakEscape()/(actual.peakEscape()+.1),full.ltv(),1e-10,"nonlinear L normalization matches loaded solve");
        var off=OperatingMetrics.calculate(dry,0);check(off.htv()==0&&off.ltv()==0&&off.score()==0&&off.power()==0,"zero rods all loaded source values zero");check(off.hotTemperature()==20&&off.meanTemperature()==20&&off.waterTemperature()==20&&off.pressure()==1,"zero rods ambient");check(Double.isNaN(off.targetRawH()),"target undefined without loading");
        var bad=OperatingMetrics.calculate(ReaCalc.evaluate(new MatrixCoefficients.Grid(3,3,3,MatrixCoefficients.Material.FUEL)),18);
        check(bad.overheat()&&Double.isNaN(bad.hotTemperature())&&Double.isNaN(bad.meanTemperature())&&Double.isNaN(bad.waterTemperature())&&Double.isNaN(bad.pressure())&&Double.isNaN(bad.output()),"all steady-state values absent during overheat");check(bad.power()>0,"overheat retains source power");
        var empty=OperatingMetrics.calculate(ReaCalc.evaluate(new MatrixCoefficients.Grid(16,4,8,MatrixCoefficients.Material.EMPTY)),0);check(empty.waterUnits()==4&&empty.meanTemperature()==20,"rectangular water rule and empty average");
        var normal=OperatingMetrics.water(300,.05,9,1000);check(normal.temperature()>100&&normal.temperature()<300,"water nominal calibration");
        double previous=20;for(double p:new double[]{0,1,100,1000,3000,10000,100000}){
            var w=OperatingMetrics.water(p,.05,9,1000);check(w.temperature()>=previous&&w.temperature()<=1000,"water monotone and no hotter than source");previous=w.temperature();
            close(w.output(),Math.min(p*.95,.6*9*(1000-w.temperature())),1e-7,"water equilibrium energy balance");check(w.output()<=p*.95+1e-8,"output never exceeds available power");
            double withoutFeedback=20+Math.min(p*.95/(9*OperatingMetrics.WATER_REMOVAL),.6*(1000-20)/(.6+OperatingMetrics.WATER_REMOVAL));check(w.temperature()<=withoutFeedback+1e-8,"pressure feedback lowers equilibrium temperature");
        }
        var hotWater=OperatingMetrics.water(1e6,0,16,2500);check(hotWater.temperature()>300&&Double.isFinite(hotWater.pressure()),"hot water can exist without core overheat");
        close(OperatingMetrics.quality(89),0,0,"cold water unusable");close(OperatingMetrics.quality(90),0,0,"90 threshold");close(OperatingMetrics.quality(145),.5,1e-12,"quality ramp");close(OperatingMetrics.quality(250),1,0,"hot quality capped");
        check(full.usefulOutput()<=full.output()&&off.usefulOutput()==0&&Double.isNaN(bad.usefulOutput()),"useful output bounded and handles off/overheat");
        var ref=ReaCalc.evaluate(MatrixCoefficients.referenceLayout());var op=OperatingMetrics.calculate(ref,4);double sum=0;for(double u:ref.raw().load())sum+=OperatingMetrics.temperature(u/ReaCalc.HEAT_BUDGET);
        close(op.meanTemperature(),sum/ref.grid().size,1e-9,"mean temperature averages individual temperatures");
    }
}
