import java.nio.file.*;
import java.util.*;
import java.awt.image.BufferedImage;

final class ReaCalcTest {
    static int checks;
    static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static void close(double a,double b,double tolerance,String message){check(Math.abs(a-b)<=tolerance,message+": "+a+" != "+b);}
    static void invalid(String text){try{ReactorIO.decode(text);throw new AssertionError("Invalid input accepted: "+text);}catch(IllegalArgumentException expected){checks++;}}
    static void same(MatrixCoefficients.Grid a,MatrixCoefficients.Grid b){check(a.nx==b.nx&&a.ny==b.ny&&a.nz==b.nz,"dimensions");for(int z=0;z<a.nz;z++)for(int y=0;y<a.ny;y++)for(int x=0;x<a.nx;x++)check(a.get(x,y,z)==b.get(x,y,z),"round trip cell");}
    static void run()throws Exception{
        var ref=ReaCalc.evaluate(MatrixCoefficients.referenceLayout());close(ref.h(),.7,1e-10,"reference H");close(ref.l(),.8186947896967386,1e-10,"reference L");
        var fuel=ReaCalc.evaluate(new MatrixCoefficients.Grid(3,3,3,MatrixCoefficients.Material.FUEL));close(fuel.h(),2.6970854831553748,1e-9,"27 fuel H");close(fuel.l(),.8812013236446732,1e-10,"27 fuel L");
        var saved=ReaCalc.evaluate(ReaCalc.resource188());close(saved.h(),.999986926012,1e-9,"188 H");close(saved.l(),.108296617389,1e-9,"188 L");check(saved.fuels()==188,"fuel count");
        var varied=new MatrixCoefficients.Grid(3,4,5,MatrixCoefficients.Material.EMPTY);Random random=new Random(7);var materials=MatrixCoefficients.Material.values();
        for(int z=0;z<5;z++)for(int y=0;y<4;y++)for(int x=0;x<3;x++)varied.set(x,y,z,materials[random.nextInt(materials.length)]);
        same(varied,ReactorIO.decode(ReactorIO.encode(varied)));
        Path temp=Files.createTempDirectory("reacalc-test-");try{for(String ext:new String[]{".json",".reacalc"}){Path f=temp.resolve("roundtrip"+ext);ReactorIO.save(f,varied);same(varied,ReactorIO.load(f));Files.delete(f);}}finally{Files.delete(temp);}
        String valid=ReactorIO.encode(varied);invalid(valid+" trailing");invalid(valid.replace("\"version\": 1","\"version\": 2"));invalid(valid.replace("[3, 4, 5]","[17, 4, 5]"));invalid(valid.replace("[3, 4, 5]","[3.5, 4, 5]"));invalid(valid.replace("FUEL","UNKNOWN"));invalid("{\"format\":\"reacalc\",\"format\":\"reacalc\"}");invalid("{" );invalid(valid.replace("[3, 4, 5]","[3, 4, 4]"));
        var empty=ReaCalc.evaluate(new MatrixCoefficients.Grid(16,16,16,MatrixCoefficients.Material.EMPTY));close(empty.h(),0,0,"empty heat");close(empty.l(),0,0,"empty leak");check(Arrays.stream(empty.raw().fastField()).sum()==0,"empty field");
        var base=new MatrixCoefficients.Grid(9,9,9,MatrixCoefficients.Material.EMPTY).set(2,4,4,MatrixCoefficients.Material.FUEL);
        var bare=ReaCalc.evaluate(base);double bareBehind=bare.raw().fastField()[base.index(5,4,4)]+bare.raw().slowField()[base.index(5,4,4)];
        double boronBehind=0,graphiteBehind=0;
        for(var m:new MatrixCoefficients.Material[]{MatrixCoefficients.Material.BORON,MatrixCoefficients.Material.GRAPHITE,MatrixCoefficients.Material.WATER}){
            var g=base.copy();for(int y=0;y<9;y++)for(int z=0;z<9;z++)g.set(4,y,z,m);var r=ReaCalc.evaluate(g);int i=g.index(5,4,4);double behind=r.raw().fastField()[i]+r.raw().slowField()[i];
            close(r.raw().emitted(),r.raw().absorbed()+r.raw().escaped(),1e-8,"signal conservation");check(behind<bareBehind,"attenuation behind "+m);
            if(m==MatrixCoefficients.Material.BORON){boronBehind=behind;check(r.raw().absorptionField()[g.index(4,4,4)]>0,"boron capture");}else{check(r.raw().slowField()[i]>bare.raw().slowField()[i],"moderation "+m);if(m==MatrixCoefficients.Material.GRAPHITE)graphiteBehind=behind;}
        }
        check(boronBehind<graphiteBehind*.5,"boron attenuates more strongly");
        var demo=ReaCalc.evaluate(ReaCalc.demo());var settings=new VolumeView.Settings(0,0,4,4,true);var c=new VolumeView.Camera(-.68,.48,1,0,0);var scene=new VolumeView.Scene(demo,c,settings,400,300);
        BufferedImage image=VolumeView.renderVolume(scene,200);check(image!=null,"volume rendered");Set<Integer> colors=new HashSet<>();for(int y=0;y<image.getHeight();y++)for(int x=0;x<image.getWidth();x++)colors.add(image.getRGB(x,y));check(colors.size()>100,"continuous gradient");
        var p=VolumeView.project(scene,3.5,4.5,4.5);var ray=VolumeView.ray(scene,p.x(),p.y());check(VolumeView.intersect(ray,3,4,4,4,5,5)!=null,"camera picking consistent");
        check(10*Math.pow(.5,1.5)>3*Math.pow(.99,1.5),"ranking 10 > 3");check(10*Math.pow(.5,1.5)<4*Math.pow(.99,1.5),"ranking 10 < 4");
        int[] counts={0,1,2,3,16,188},caps={0,3,4,5,18,18};for(int i=0;i<counts.length;i++)check(ReactorIO.capacity(counts[i])==caps[i],"rod capacity "+counts[i]);
        var loaded=ReactorIO.decodeDocument(ReactorIO.encodeDocument(varied,3));same(varied,loaded.grid());check(loaded.loadedRods()==3,"rod JSON roundtrip");check(ReactorIO.decodeDocument(ReactorIO.encode(varied)).loadedRods()==0,"old file defaults to zero rods");
        invalid(ReactorIO.encodeDocument(varied,3).replace("\"loadedRods\": 3","\"loadedRods\": 19"));invalid(ReactorIO.encodeDocument(varied,3).replace("\"loadedRods\": 3","\"loadedRods\": -1"));invalid(ReactorIO.encodeDocument(varied,3).replace("\"loadedRods\": 3","\"loadedRods\": 1.5"));
        Path loadedFile=Files.createTempFile("reacalc-rods-",".json");try{ReactorIO.saveDocument(loadedFile,varied,3);check(ReactorIO.loadDocument(loadedFile).loadedRods()==3,"rod file roundtrip");}finally{Files.delete(loadedFile);}
        String clip=LayerCopy.encode(varied,1);var pasted=LayerCopy.paste(varied,4,clip);
        for(int z=0;z<5;z++)for(int y=0;y<4;y++)for(int x=0;x<3;x++)check(pasted.get(x,y,z)==varied.get(x,y,z==4?1:z),"whole layer paste including empty cells");
        try{LayerCopy.paste(new MatrixCoefficients.Grid(4,4,5,MatrixCoefficients.Material.EMPTY),0,clip);throw new AssertionError("mismatched paste accepted");}catch(IllegalArgumentException expected){checks++;}
        try{LayerCopy.paste(varied,0,"unrelated text");throw new AssertionError("unrelated clipboard accepted");}catch(IllegalArgumentException expected){checks++;}
        OperatingMetricsTest.run();
        SchematicIOTest.run();TutorialCatalogTest.run();
        HeatDynamicsTest.run();
        System.out.println("PASS "+checks+" checks; transport, loading, equilibrium, JSON, renderer, camera.");
    }
    static javax.swing.AbstractButton findButton(java.awt.Container c,String text){
        for(var child:c.getComponents()){if(child instanceof javax.swing.AbstractButton b&&text.equals(b.getText()))return b;if(child instanceof java.awt.Container inner){var found=findButton(inner,text);if(found!=null)return found;}}return null;
    }
    static void runUi()throws Exception{
        javax.swing.SwingUtilities.invokeAndWait(()->{
            ReaCalc.theme();ReaCalc app=new ReaCalc();
            app.layerClipboard=new java.awt.datatransfer.Clipboard("isolated-ui-test");
            try{
                app.tabs.setSelectedIndex(1);app.frame.addNotify();app.frame.validate();app.solveTimer.stop();if(app.solveTask!=null)app.solveTask.cancel(true);
                check(app.editor.getWidth()>200&&app.editor.getHeight()>200,"editor laid out");
                findButton(app.frame,"Бор").doClick();check(app.brush==MatrixCoefficients.Material.BORON,"brush button");
                int x=(int)(app.editor.offsetX()+7.5*app.editor.cell()),y=(int)(app.editor.offsetY()+7.5*app.editor.cell());
                app.editor.dispatchEvent(new java.awt.event.MouseEvent(app.editor,java.awt.event.MouseEvent.MOUSE_PRESSED,0,0,x,y,1,false,1));
                app.editor.dispatchEvent(new java.awt.event.MouseEvent(app.editor,java.awt.event.MouseEvent.MOUSE_RELEASED,1,0,x,y,1,false,1));
                check(app.grid.get(7,7,4)==MatrixCoefficients.Material.BORON,"mouse painting");
                findButton(app.frame,"Отменить").doClick();check(app.grid.get(7,7,4)==MatrixCoefficients.Material.EMPTY,"undo click");
                findButton(app.frame,"Повторить").doClick();check(app.grid.get(7,7,4)==MatrixCoefficients.Material.BORON,"redo click");
                app.editor.dispatchEvent(new java.awt.event.MouseEvent(app.editor,java.awt.event.MouseEvent.MOUSE_PRESSED,2,0,x,y,1,false,3));
                app.editor.dispatchEvent(new java.awt.event.MouseEvent(app.editor,java.awt.event.MouseEvent.MOUSE_RELEASED,3,0,x,y,1,false,3));
                check(app.grid.get(7,7,4)==MatrixCoefficients.Material.EMPTY,"right-click erase");
                app.layer.setValue(2);check(app.volume.layer==2,"slice control");app.cut.setSelectedIndex(2);check(app.volume.cut==2,"cut control");app.mode.setSelectedIndex(3);check(app.volume.mode==3,"field mode");
                double angle=app.volume.yaw;
                app.volume.dispatchEvent(new java.awt.event.MouseEvent(app.volume,java.awt.event.MouseEvent.MOUSE_PRESSED,4,0,150,150,1,false,1));
                app.volume.dispatchEvent(new java.awt.event.MouseEvent(app.volume,java.awt.event.MouseEvent.MOUSE_DRAGGED,5,java.awt.event.InputEvent.BUTTON1_DOWN_MASK,200,160,1,false,0));
                app.volume.dispatchEvent(new java.awt.event.MouseEvent(app.volume,java.awt.event.MouseEvent.MOUSE_RELEASED,6,0,200,160,1,false,1));
                check(app.volume.yaw!=angle,"camera drag");
                app.nx.setValue(16);app.ny.setValue(16);app.nz.setValue(16);findButton(app.frame,"Применить размер · до 16³").doClick();check(app.grid.size==4096&&app.grid.get(3,4,4)==MatrixCoefficients.Material.FUEL,"resize preserves contents");
                Path path=Files.createTempFile("reacalc-ui-",".reacalc");try{ReactorIO.save(path,MatrixCoefficients.referenceLayout());app.load(path);check(app.grid.size==27&&!app.dirty,"load commits configuration");}finally{Files.delete(path);}
                app.frame.setSize(1120,760);app.frame.validate();check(app.volume.getWidth()>400&&app.editor.getWidth()>200,"minimum window usable");
                app.layer.setValue(1);app.rods.setValue(6);check(app.loadedRods==6,"rod spinner");app.history(false);check(app.loadedRods==0,"rod change undo");app.history(true);check(app.loadedRods==6,"rod change redo");
                app.frame.getRootPane().getActionMap().get("key-control C").actionPerformed(null);app.layer.setValue(0);app.frame.getRootPane().getActionMap().get("key-control V").actionPerformed(null);
                check(app.grid.get(1,0,0)==MatrixCoefficients.Material.FUEL&&app.grid.get(0,0,0)==MatrixCoefficients.Material.GRAPHITE,"Ctrl C/V layer action");check(app.loadedRods==6,"paste preserves rod count");
                app.history(false);check(app.grid.get(1,0,0)==MatrixCoefficients.Material.WATER,"paste single undo");
                app.checkpoint();app.grid=new MatrixCoefficients.Grid(3,3,3,MatrixCoefficients.Material.EMPTY).set(1,1,1,MatrixCoefficients.Material.FUEL);app.changed();check(app.loadedRods==3,"capacity reduction clamps rods");app.history(false);check(app.loadedRods==6,"undo restores clamped rods");
                long previousRevision=app.revision;app.rods.setValue(5);check(app.revision==previousRevision,"rods do not alter dry calculation");
                Path loadedPath=Files.createTempFile("reacalc-loaded-ui-",".reacalc");try{ReactorIO.saveDocument(loadedPath,app.grid,5);app.load(loadedPath);check(app.loadedRods==5&&!app.dirty,"UI loads rod count");}finally{Files.delete(loadedPath);}
                app.revision++;if(app.solveTask!=null)app.solveTask.cancel(true);app.solveTimer.stop();app.calculated=ReaCalc.evaluate(app.grid);app.updateOperating();double oldHtv=app.operating.htv();app.rods.setValue(2);check(app.operating.htv()<oldHtv,"loading updates Htv immediately");
                check(app.metrics.values.values().stream().allMatch(l->l.getToolTipText()!=null),"all detailed metrics have tooltips");check(app.heat.getToolTipText()!=null&&app.htvLabel.getToolTipText()!=null&&app.score.getToolTipText()!=null&&app.leak.getToolTipText()!=null,"card tooltips");
                app.rods.setValue(0);check(app.operating.waterTemperature()==20&&app.operating.power()==0,"UI empty loading");
                check(app.presets.getItemCount()==32,"legacy and new presets listed");check(app.presets.getItemAt(6).equals("188 чехлов / 16³"),"legacy188 stays available");
                app.loadPreset(8);check(app.grid.nx==2&&app.loadedRods==5,"tutorial opens with loading");
                app.loadPreset(23);check(ReaCalc.countFuel(app.grid)==188&&app.loadedRods==18,"working188 opens full");
                app.history(false);check(app.grid.nx==2&&app.loadedRods==5,"undo tutorial restores loading");
                check(findButton(app.frame,"Экспорт Minecraft .schem…")!=null,"schematic export UI");
                app.loadPreset(24);check(app.grid.nx==2&&app.loadedRods==4,"weak extreme loads");
                app.loadPreset(31);check(app.grid.nx==16&&app.loadedRods==18,"strong16 extreme loads");
                app.revision++;if(app.solveTask!=null)app.solveTask.cancel(true);app.solveTimer.stop();app.calculated=ReaCalc.evaluate(app.grid);app.updateOperating();
                app.viewTabs.setSelectedIndex(1);app.frame.validate();check(app.heating.chart.getWidth()>400,"timeline chart laid out");
                check(app.heating.state.temperature()==20&&app.heating.state.useful()==0,"preset starts cold");
                app.heating.step.doClick();double warm=app.heating.state.temperature();check(warm>20&&app.heating.state.useful()>0,"step warms and generates output");
                close(app.heating.state.useful(),new HeatOutputCurve(app.calculated).at(warm).useful(),1e-9,"UI geometry temperature curve");
                check(app.heating.history.size()>2,"timeline samples curve between manual steps");
                double priorOutput=app.heating.state.useful(),priorExchange=app.heating.state.exchange();app.rods.setValue(17);close(app.heating.state.temperature(),warm,0,"UI rod change retains heat");close(app.heating.state.useful(),priorOutput,1e-9,"UI rod change retains useful output");close(app.heating.state.exchange(),priorExchange,1e-9,"UI rod change retains exchange");
                app.rods.setValue(0);double residual=app.heating.state.useful();app.heating.step.doClick();close(app.heating.state.temperature(),warm,1e-9,"UI unload holds before cooling");app.heating.step.doClick();check(app.heating.state.temperature()<warm&&app.heating.state.useful()<residual,"UI unloaded core cools");check(app.heating.reference.getText().contains("Остывание"),"UI displays cooling estimate instead of warmup tau");
                app.heating.reset.doClick();check(app.heating.state.temperature()==20&&app.heating.state.ticks==0,"cold restart button");
                app.heating.start.doClick();check(app.heating.timer.isRunning(),"start timeline");app.heating.pending();check(!app.heating.timer.isRunning()&&!app.heating.start.isEnabled(),"pending calculation pauses timeline");
                app.updateOperating();check(app.heating.start.isEnabled(),"calculation enables timeline");
                System.out.println("PASS "+checks+" UI checks; edit, erase, undo/redo, slice, mode, rotation, resize, load.");
            }catch(Exception ex){throw new RuntimeException(ex);}finally{app.revision++;app.shutdown();app.frame.dispose();}
        });
    }
}
