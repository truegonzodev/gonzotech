import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPOutputStream;

/** Sponge schematic v2, Minecraft Java 1.21.4. Axes are preserved, Y is up. */
final class SchematicIO {
    static final int DATA_VERSION=4189;
    static String block(MatrixCoefficients.Material material){return switch(material){
        case BORON -> "gonzotech:boron_block";
        case BARIUM -> "gonzotech:barium_block";
        case GRAPHITE -> "gonzotech:graphite_block";
        case FUEL -> "gonzotech:third_uranium_reactor_fuel_sheath";
        case WATER -> "minecraft:water[level=0]";
        case EMPTY -> "minecraft:air";
    };}
    static byte[] encode(MatrixCoefficients.Grid grid,int rods,String name)throws IOException{
        ReactorIO.validateRods(grid,rods);
        if(grid.nx>16||grid.ny>16||grid.nz>16)throw new IllegalArgumentException("Размер экспорта: до 16 по каждой оси.");
        Map<String,Integer> palette=new LinkedHashMap<>();palette.put("minecraft:air",0);
        ByteArrayOutputStream blocks=new ByteArrayOutputStream();
        // Sponge uses X then Z then Y, unlike ReaCalc's X then Y then Z.
        for(int y=0;y<grid.ny;y++)for(int z=0;z<grid.nz;z++)for(int x=0;x<grid.nx;x++){
            String state=block(grid.get(x,y,z));int id=palette.computeIfAbsent(state,k->palette.size());
            do{int b=id&127;id>>>=7;blocks.write(id==0?b:b|128);}while(id!=0);
        }
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(DataOutputStream out=new DataOutputStream(new GZIPOutputStream(bytes))){
            tag(out,10,"Schematic");integer(out,"Version",2);integer(out,"DataVersion",DATA_VERSION);
            shortTag(out,"Width",grid.nx);shortTag(out,"Height",grid.ny);shortTag(out,"Length",grid.nz);
            tag(out,11,"Offset");out.writeInt(3);out.writeInt(0);out.writeInt(0);out.writeInt(0);
            tag(out,10,"Metadata");string(out,"Name",name);string(out,"Author","ReaCalc");
            tag(out,9,"RequiredMods");out.writeByte(8);out.writeInt(palette.keySet().stream().anyMatch(k->k.startsWith("gonzotech:"))?1:0);
            if(palette.keySet().stream().anyMatch(k->k.startsWith("gonzotech:")))out.writeUTF("gonzotech");
            tag(out,10,"ReaCalc");integer(out,"LoadedRods",rods);string(out,"Note","Geometry only; fuel inventory is not placed.");out.writeByte(0);out.writeByte(0);
            integer(out,"PaletteMax",palette.size());tag(out,10,"Palette");
            for(var e:palette.entrySet())integer(out,e.getKey(),e.getValue());out.writeByte(0);
            tag(out,7,"BlockData");out.writeInt(blocks.size());blocks.writeTo(out);
            emptyList(out,"BlockEntities");emptyList(out,"Entities");out.writeByte(0);
        }
        return bytes.toByteArray();
    }
    static void save(Path target,MatrixCoefficients.Grid grid,int rods)throws IOException{
        byte[] bytes=encode(grid,rods,target.getFileName().toString());Path absolute=target.toAbsolutePath();
        Path temporary=Files.createTempFile(absolute.getParent(),".reacalc-schem-",".tmp");
        try{Files.write(temporary,bytes);try{Files.move(temporary,absolute,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException e){Files.move(temporary,absolute,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(temporary);}
    }
    private static void tag(DataOutputStream out,int type,String name)throws IOException{out.writeByte(type);out.writeUTF(name);}
    private static void integer(DataOutputStream out,String name,int value)throws IOException{tag(out,3,name);out.writeInt(value);}
    private static void shortTag(DataOutputStream out,String name,int value)throws IOException{tag(out,2,name);out.writeShort(value);}
    private static void string(DataOutputStream out,String name,String value)throws IOException{tag(out,8,name);out.writeUTF(value);}
    private static void emptyList(DataOutputStream out,String name)throws IOException{tag(out,9,name);out.writeByte(10);out.writeInt(0);}
}
