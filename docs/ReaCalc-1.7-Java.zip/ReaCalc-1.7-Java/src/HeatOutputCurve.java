/** Fixed-geometry temperature-to-output curve. Actual rod count is never an input. */
final class HeatOutputCurve {
    record Output(double exchange,double useful){}
    static final Output ZERO=new Output(0,0);
    final double rawH,rawL,qDry,meanShape,anchorTemperature;
    final int waterUnits;
    final Output anchor;
    HeatOutputCurve(VolumeView.Result result){
        rawH=result.h();rawL=result.l();var g=result.grid();waterUnits=Math.min(g.nx,Math.min(g.ny,g.nz));
        double sum=0,q=0;int count=0;
        for(int z=0;z<g.nz;z++)for(int y=0;y<g.ny;y++)for(int x=0;x<g.nx;x++){
            int i=g.index(x,y,z);q+=result.raw().heatProduction()[i];
            if(g.get(x,y,z)!=MatrixCoefficients.Material.EMPTY){
                count++;if(rawH>0)sum+=Math.pow(Math.max(0,result.raw().load()[i]/ReaCalc.HEAT_BUDGET/rawH),OperatingMetrics.TEMP_EXPONENT);
            }
        }
        qDry=q;meanShape=count==0?0:sum/count;
        anchorTemperature=OperatingMetrics.AMBIENT+OperatingMetrics.TEMP_SCALE;
        anchor=equilibrium(anchorTemperature);
    }
    private Output equilibrium(double temperature){
        double rise=Math.max(0,temperature-OperatingMetrics.AMBIENT);
        if(rawH<=0||qDry<=0||rise==0)return ZERO;
        double h=Math.pow(rise/OperatingMetrics.TEMP_SCALE,1/OperatingMetrics.TEMP_EXPONENT);
        double ratio=h/rawH;
        var w=OperatingMetrics.water(OperatingMetrics.POWER_SCALE*ratio*qDry,
                OperatingMetrics.scaledLeak(rawL,ratio),waterUnits,OperatingMetrics.AMBIENT+rise*meanShape);
        double q=OperatingMetrics.OUTPUT_GAIN*w.output();
        return new Output(q,q*OperatingMetrics.quality(w.temperature()));
    }
    Output at(double temperature){
        if(temperature<=anchorTemperature)return equilibrium(temperature);
        double scale=(temperature-OperatingMetrics.AMBIENT)/(anchorTemperature-OperatingMetrics.AMBIENT);
        return new Output(anchor.exchange*scale,anchor.useful*scale);
    }
}
