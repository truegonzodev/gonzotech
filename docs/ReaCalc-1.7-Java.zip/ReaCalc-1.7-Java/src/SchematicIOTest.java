import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Independent NBT reader used only by tests to inspect actual exported bytes. */
final class SchematicIOTest {
    static void check(boolean condition,String message){ReaCalcTest.check(condition,message);}
    static Map<String,Object> read(byte[] bytes)throws IOException{
        try(var in=new DataInputStream(new GZIPInputStream(new ByteArrayInputStream(bytes)))){
            check(in.readUnsignedByte()==10&&in.readUTF().equals("Schematic"),"schem root");
            var root=compound(in);check(in.read()==-1,"no trailing NBT");return root;
        }
    }
    static Map<String,Object> compound(DataInputStream in)throws IOException{
        var fields=new LinkedHashMap<String,Object>();int type;
        while((type=in.readUnsignedByte())!=0){String name=in.readUTF();check(!fields.containsKey(name),"unique NBT tag");fields.put(name,payload(in,type));}return fields;
    }
    static Object payload(DataInputStream in,int type)throws IOException{return switch(type){
        case 2->in.readUnsignedShort();case 3->in.readInt();case 8->in.readUTF();
        case 7->{int size=in.readInt();byte[] data=new byte[size];in.readFully(data);yield data;}
        case 9->{int item=in.readUnsignedByte(),size=in.readInt();List<Object> list=new ArrayList<>();for(int i=0;i<size;i++)list.add(payload(in,item));yield list;}
        case 10->compound(in);
        case 11->{int[] values=new int[in.readInt()];for(int i=0;i<values.length;i++)values[i]=in.readInt();yield values;}
        default->throw new IOException("Unexpected tag "+type);
    };}
    static String[] states(Map<String,Object> root)throws IOException{
        var palette=(Map<?,?>)root.get("Palette");String[] ids=new String[(int)root.get("PaletteMax")];
        for(var e:palette.entrySet())ids[(int)e.getValue()]=(String)e.getKey();
        int count=(int)root.get("Width")*(int)root.get("Height")*(int)root.get("Length");String[] states=new String[count];
        try(var in=new ByteArrayInputStream((byte[])root.get("BlockData"))){for(int i=0;i<count;i++){
            int id=0,shift=0,b;do{b=in.read();if(b<0||shift>28)throw new IOException("Invalid varint");id|=(b&127)<<shift;shift+=7;}while((b&128)!=0);
            if(id>=ids.length||ids[id]==null)throw new IOException("Invalid palette index");states[i]=ids[id];
        }check(in.read()==-1,"exact BlockData length");}return states;
    }
    static void run()throws Exception{
        var materials=MatrixCoefficients.Material.values();String[] expected={"gonzotech:third_uranium_reactor_fuel_sheath","minecraft:water[level=0]","gonzotech:graphite_block","gonzotech:boron_block","gonzotech:barium_block","minecraft:air"};
        var grid=new MatrixCoefficients.Grid(2,3,4,MatrixCoefficients.Material.EMPTY);
        for(int z=0;z<4;z++)for(int y=0;y<3;y++)for(int x=0;x<2;x++)grid.set(x,y,z,materials[(x+2*y+3*z)%6]);
        byte[] bytes=SchematicIO.encode(grid,3,"Учебный реактор");check((bytes[0]&255)==31&&(bytes[1]&255)==139,"gzip magic");
        var root=read(bytes);check(root.get("Version").equals(2),"Sponge v2");check(root.get("DataVersion").equals(4189),"Minecraft 1.21.4 DataVersion");
        check(root.get("Width").equals(2)&&root.get("Height").equals(3)&&root.get("Length").equals(4),"noncubic axes");
        check(Arrays.equals((int[])root.get("Offset"),new int[]{0,0,0}),"zero origin");
        var metadata=(Map<?,?>)root.get("Metadata");check(metadata.get("Name").equals("Учебный реактор"),"UTF8 NBT metadata");
        check(((Map<?,?>)metadata.get("ReaCalc")).get("LoadedRods").equals(3),"loading metadata");
        check(((List<?>)root.get("BlockEntities")).isEmpty(),"no invented fuel inventory");check(((List<?>)root.get("Entities")).isEmpty(),"no entities");
        String[] output=states(root);for(int y=0;y<3;y++)for(int z=0;z<4;z++)for(int x=0;x<2;x++)check(output[x+2*(z+4*y)].equals(expected[(x+2*y+3*z)%6]),"orientation and exact block state");
        var empty=new MatrixCoefficients.Grid(1,1,1,MatrixCoefficients.Material.EMPTY);check(states(read(SchematicIO.encode(empty,0,"empty")))[0].equals("minecraft:air"),"empty export");
        Path file=Files.createTempFile("reacalc-schematic-",".schem");try{
            SchematicIO.save(file,grid,3);check(Arrays.equals(states(read(Files.readAllBytes(file))),output),"file export");
            byte[] before=Files.readAllBytes(file);try{SchematicIO.save(file,empty,1);throw new AssertionError("Invalid load exported");}catch(IllegalArgumentException expectedError){check(Arrays.equals(before,Files.readAllBytes(file)),"failed export preserves file");}
            SchematicIO.save(file,empty,0);check(states(read(Files.readAllBytes(file))).length==1,"replace export");
        }finally{Files.deleteIfExists(file);}
    }
}
