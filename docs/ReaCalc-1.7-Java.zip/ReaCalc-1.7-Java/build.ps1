$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
New-Item -ItemType Directory -Force build\classes | Out-Null
$sources = Get-ChildItem src\*.java | ForEach-Object { $_.FullName }
& javac -encoding UTF-8 --release 21 -d build\classes $sources
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
Copy-Item examples\best-score-188.txt build\classes\best-score-188.txt -Force
New-Item -ItemType Directory -Force build\classes\tutorials | Out-Null
Copy-Item examples\tutorials\*.reacalc build\classes\tutorials -Force
& jar --create --file ReaCalc.jar --main-class ReaCalc -C build\classes .
if ($LASTEXITCODE -ne 0) { throw 'Packaging failed' }
& java -jar ReaCalc.jar --test
if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
