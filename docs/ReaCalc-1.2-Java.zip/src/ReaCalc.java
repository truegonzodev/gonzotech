import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import javax.imageio.ImageIO;

public final class ReaCalc {
    static final Color BG=new Color(15,19,31),PANEL=new Color(24,30,46),TEXT=new Color(224,231,245),MUTED=new Color(144,160,186),ACCENT=new Color(97,221,198);
    static final MatrixCoefficients.Rules RULES=MatrixCoefficients.Rules.defaults();
    static final double HEAT_BUDGET=MatrixCoefficients.balancedDefault().calibration().heatBudget();
    final JFrame frame=new JFrame("ReaCalc — визуальный калькулятор реактора");
    MatrixCoefficients.Grid grid=demo();
    MatrixCoefficients.Material brush=MatrixCoefficients.Material.FUEL;
    final VolumeView volume;
    final SliceEditor editor=new SliceEditor();
    final JLabel status=new JLabel("Расчёт…"),heat=new JLabel("—"),leak=new JLabel("—"),fuel=new JLabel("—"),score=new JLabel("—"),selection=new JLabel("Клетка не выбрана");
    final JLabel layerText=new JLabel(),inspector=new JLabel(),materialInfo=new JLabel();
    final JSlider layer=new JSlider(0,8,4),exposure=new JSlider(5,100,40);
    final JSpinner nx=new JSpinner(new SpinnerNumberModel(9,1,16,1)),ny=new JSpinner(new SpinnerNumberModel(9,1,16,1)),nz=new JSpinner(new SpinnerNumberModel(9,1,16,1));
    final JComboBox<String> cut=new JComboBox<>(new String[]{"Весь объём","Только слой Z","Срез до слоя Z"});
    final JComboBox<String> mode=new JComboBox<>(new String[]{"Нейтронное поле","Быстрая компонента","Замедленная компонента","Поглощение","Тепловая нагрузка"});
    record EditState(MatrixCoefficients.Grid grid,int rods,int layer){}
    final ArrayDeque<EditState> undo=new ArrayDeque<>(),redo=new ArrayDeque<>();
    int loadedRods;
    boolean updatingRods;
    final JSpinner rods=new JSpinner(new SpinnerNumberModel(0,0,3,1));
    final JLabel rodCapacity=new JLabel(),rodAverage=new JLabel();
    final JLabel htvLabel=new JLabel("—");
    final MetricsPanel metrics=new MetricsPanel();
    final JTabbedPane tabs=new JTabbedPane();
    OperatingMetrics.Values operating;
    Clipboard layerClipboard=Toolkit.getDefaultToolkit().getSystemClipboard();
    final ExecutorService solver=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"reacalc-solver");t.setDaemon(true);return t;});
    final javax.swing.Timer solveTimer;
    Future<?> solveTask;
    long revision;
    boolean dirty,updating;
    int sx=-1,sy=-1,sz=-1;
    Path currentFile;
    VolumeView.Result calculated;

    ReaCalc(){
        volume=new VolumeView((x,y,z,paint,erase)->{select(x,y,z);if(paint){checkpoint();setCell(x,y,z,erase?MatrixCoefficients.Material.EMPTY:brush);changed();}});
        solveTimer=new javax.swing.Timer(150,e->calculate());solveTimer.setRepeats(false);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){if(confirmLeave()){shutdown();frame.dispose();}}});
        frame.setMinimumSize(new Dimension(1120,760));frame.setSize(1450,940);frame.setLocationRelativeTo(null);
        frame.setIconImage(AssetMaker.icon());
        ToolTipManager.sharedInstance().setInitialDelay(250);ToolTipManager.sharedInstance().setDismissDelay(30000);
        heat.setToolTipText(MetricsPanel.tip("Сырой H: максимум u/Ubudget при единичном источнике в каждом чехле. Не зависит от загрузки и может превышать 1. Перегрев теперь определяет Htv, а не rawH."));
        leak.setToolTipText(MetricsPanel.tip("Сырой L исходной конструкции при единичных источниках. Показано 100×L процентов шкалы максимальной граничной утечки. Загруженный Ltv находится во вкладке «Расчёт»."));
        htvLabel.setToolTipText(MetricsPanel.tip("Htv=rawH×R/N: линейный пересчёт на равномерную загрузку ТВЭЛов. R — ТВЭЛы, N — чехлы. При R=0 Htv=0. При Htv≥1 плато отсутствует и температуры показывают NaN / перегрев."));
        score.setToolTipText(MetricsPanel.tip("Рейтинг загруженной сборки: S=N×Htv^1.5×(1−Ltv), только при Htv<1. При перегреве устойчивый рейтинг не определён. S — игровой рейтинг, а не единицы выходного тепла."));
        fuel.setPreferredSize(new Dimension(40,24));fuel.setToolTipText(MetricsPanel.tip("N — количество чехлов. Каждому назначается одинаковая дробная загрузка R/N; индивидуальное размещение целых ТВЭЛов пока не задаётся."));
        rods.setToolTipText(MetricsPanel.tip("Общее число загруженных ТВЭЛов R. Лимит: min(N+2,18), при N=0 доступно 0 слотов. Загрузка сохраняется в файле."));
        rodCapacity.setToolTipText(rods.getToolTipText());rodAverage.setToolTipText(MetricsPanel.tip("Средняя загрузка R/N. При 18 ТВЭЛах и 188 чехлах: 0.09574468. Этим множителем масштабируются H и суммарное производство тепла."));
        ((JSpinner.NumberEditor)rods.getEditor()).getTextField().setToolTipText(rods.getToolTipText());status.setToolTipText(MetricsPanel.tip("Размеры конструкции, режим по Htv и средняя загрузка r=R/N. 3D изображает сухое поле, численные загруженные показатели находятся сверху и во вкладке «Расчёт»."));
        JPanel root=new JPanel(new BorderLayout(12,12));root.setBackground(BG);root.setBorder(new EmptyBorder(16,18,12,18));frame.setContentPane(root);
        root.add(header(),BorderLayout.NORTH);
        JPanel center=new JPanel(new BorderLayout(0,10));center.setOpaque(false);
        JPanel cards=new JPanel(new GridLayout(1,4,10,0));cards.setOpaque(false);
        cards.add(card("СЫРОЙ  rawH",heat,"Конструкция · единичные источники"));
        cards.add(card("СЫРАЯ УТЕЧКА  L",leak,"Загруженный Ltv — в расчёте"));
        cards.add(card("НАГРУЗКА ТВЭЛОВ  Htv",htvLabel,"rawH × R / N · перегрев от 1"));
        cards.add(card("РЕЙТИНГ ЗАГРУЗКИ  S",score,"N × Htv¹·⁵ × (1 − Ltv)"));
        JPanel summary=new JPanel(new BorderLayout(0,8));summary.setOpaque(false);summary.add(cards,BorderLayout.NORTH);
        JPanel loading=new JPanel(new FlowLayout(FlowLayout.LEFT,10,8));loading.setBackground(PANEL);loading.add(label("ТВЭЛЫ",true));rods.setPreferredSize(new Dimension(62,28));loading.add(rods);loading.add(rodCapacity);loading.add(label("Чехлы:",false));loading.add(fuel);loading.add(rodAverage);
        loading.add(button("Загрузить максимум",()->rods.setValue(ReactorIO.capacity(countFuel(grid)))));
        JPanel loadingPanel=new JPanel(new BorderLayout());loadingPanel.setBackground(PANEL);loadingPanel.add(loading,BorderLayout.CENTER);JLabel loadingNote=label("3D — сухое поле · Htv, температуры и водяной контур учитывают загрузку",false);loadingNote.setToolTipText(MetricsPanel.tip("Визуализация и rawH/L остаются исходной конструкцией для сравнения проектов. Загруженные численные показатели пересчитываются мгновенно при изменении числа ТВЭЛов."));loadingNote.setBorder(new EmptyBorder(0,12,7,0));loadingPanel.add(loadingNote,BorderLayout.SOUTH);summary.add(loadingPanel,BorderLayout.SOUTH);center.add(summary,BorderLayout.NORTH);
        JPanel canvas=new JPanel(new BorderLayout());canvas.setBackground(PANEL);canvas.setBorder(new LineBorder(new Color(47,57,79)));
        JPanel tools=new JPanel(new FlowLayout(FlowLayout.LEFT,10,8));tools.setBackground(PANEL);
        tools.add(mode);tools.add(cut);JCheckBox blocks=new JCheckBox("Контуры блоков",true);tools.add(blocks);tools.add(button("Сброс вида",volume::reset));
        mode.addActionListener(e->{volume.mode=mode.getSelectedIndex();volume.requestRender();});
        cut.addActionListener(e->{volume.cut=cut.getSelectedIndex();volume.requestRender();});
        blocks.addActionListener(e->{volume.blocks=blocks.isSelected();volume.requestRender();});
        canvas.add(tools,BorderLayout.NORTH);canvas.add(volume,BorderLayout.CENTER);center.add(canvas,BorderLayout.CENTER);root.add(center,BorderLayout.CENTER);
        tabs.setPreferredSize(new Dimension(365,0));tabs.addTab("Расчёт",scroll(metrics));tabs.addTab("Конструкция",scroll(sidebar()));root.add(tabs,BorderLayout.EAST);
        status.setForeground(MUTED);status.setFont(new Font("Segoe UI",Font.PLAIN,12));root.add(status,BorderLayout.SOUTH);
        layer.addChangeListener(e->{if(updating)return;volume.layer=layer.getValue();updateLayerLabel();editor.repaint();volume.requestRender();});
        exposure.addChangeListener(e->{volume.exposure=exposure.getValue()/10.;volume.requestRender();});
        key("control Z",()->history(false));key("control Y",()->history(true));key("control O",this::open);key("control S",()->save(false));key("control shift S",()->save(true));key("R",volume::reset);
        key("control C",this::copyLayer);key("control V",this::pasteLayer);
        rods.addChangeListener(e->{if(updatingRods)return;checkpoint();loadedRods=(int)rods.getValue();updateLoading();dirty=true;updateTitle();updateOperating();});
        frame.setTransferHandler(new TransferHandler(){public boolean canImport(TransferSupport s){return s.isDataFlavorSupported(java.awt.datatransfer.DataFlavor.javaFileListFlavor);}public boolean importData(TransferSupport s){try{if(!canImport(s))return false;var files=(java.util.List<?>)s.getTransferable().getTransferData(java.awt.datatransfer.DataFlavor.javaFileListFlavor);if(files.isEmpty()||!confirmLeave())return false;load(((java.io.File)files.getFirst()).toPath());return true;}catch(Exception ex){error(ex);return false;}}});
        synchronize();calculate();
    }
    static void theme(){
        UIManager.put("TabbedPane.background",PANEL);UIManager.put("TabbedPane.foreground",TEXT);UIManager.put("TabbedPane.selected",new Color(42,58,77));
        UIManager.put("Panel.background",PANEL);UIManager.put("Label.foreground",TEXT);UIManager.put("Button.background",new Color(39,49,70));UIManager.put("Button.foreground",TEXT);
        UIManager.put("ToggleButton.background",new Color(39,49,70));UIManager.put("ToggleButton.foreground",TEXT);UIManager.put("ToggleButton.select",new Color(51,91,101));
        UIManager.put("ComboBox.background",new Color(36,45,64));UIManager.put("ComboBox.foreground",TEXT);UIManager.put("ComboBox.selectionBackground",new Color(52,81,99));UIManager.put("ComboBox.selectionForeground",TEXT);
        UIManager.put("TextField.background",new Color(32,40,59));UIManager.put("TextField.foreground",TEXT);UIManager.put("TextField.caretForeground",TEXT);
        UIManager.put("FormattedTextField.background",new Color(32,40,59));UIManager.put("FormattedTextField.foreground",TEXT);
        UIManager.put("ScrollBar.thumb",new Color(61,76,99));UIManager.put("ScrollBar.track",PANEL);UIManager.put("ScrollBar.background",PANEL);UIManager.put("ScrollBar.thumbShadow",PANEL);UIManager.put("ScrollBar.thumbHighlight",new Color(69,86,113));
        UIManager.put("Spinner.background",PANEL);UIManager.put("Spinner.foreground",TEXT);UIManager.put("CheckBox.background",PANEL);UIManager.put("CheckBox.foreground",TEXT);UIManager.put("Slider.background",PANEL);UIManager.put("Slider.foreground",ACCENT);
        UIManager.put("ScrollPane.background",PANEL);UIManager.put("Viewport.background",PANEL);UIManager.put("OptionPane.background",PANEL);UIManager.put("OptionPane.messageForeground",TEXT);
        var keys=UIManager.getDefaults().keys();while(keys.hasMoreElements()){Object k=keys.nextElement();if(k.toString().endsWith(".font"))UIManager.put(k,new javax.swing.plaf.FontUIResource("Segoe UI",Font.PLAIN,13));}
    }
    JPanel header(){
        JPanel p=new JPanel(new BorderLayout());p.setOpaque(false);JPanel title=new JPanel(new GridLayout(2,1,0,0));title.setOpaque(false);
        JLabel brand=new JLabel("REA CALC");brand.setFont(new Font("Segoe UI",Font.BOLD,26));brand.setForeground(ACCENT);title.add(brand);
        JLabel sub=new JLabel("Объёмное поле · редактор сборки · игровой баланс");sub.setForeground(MUTED);title.add(sub);p.add(title,BorderLayout.WEST);
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.RIGHT,8,8));actions.setOpaque(false);
        JComboBox<String> preset=new JComboBox<>(new String[]{"Пример: поле и бор","Эталон H = 0,70","27 чехлов","Чехол в графите","Чехол в воде","Чехол в боре","188 чехлов / 16³","Пустой объём"});
        preset.setPreferredSize(new Dimension(190,32));actions.add(preset);actions.add(button("Загрузить пример",()->{
            if(!confirmLeave())return;int v=preset.getSelectedIndex();
            try{var next=switch(v){case 1->MatrixCoefficients.referenceLayout();case 2->new MatrixCoefficients.Grid(3,3,3,MatrixCoefficients.Material.FUEL);case 3->surrounded(MatrixCoefficients.Material.GRAPHITE);case 4->surrounded(MatrixCoefficients.Material.WATER);case 5->surrounded(MatrixCoefficients.Material.BORON);case 6->resource188();case 7->new MatrixCoefficients.Grid(9,9,9,MatrixCoefficients.Material.EMPTY);default->demo();};
                checkpoint();grid=next;loadedRods=0;currentFile=null;synchronize();cut.setSelectedIndex(v==3||v==4||v==5||v==6?1:0);volume.reset();changed();
            }catch(Exception ex){error(ex);}
        }));
        actions.add(button("Открыть…",this::open));actions.add(button("Сохранить…",()->save(true)));p.add(actions,BorderLayout.EAST);return p;
    }
    JPanel card(String title,JLabel value,String hint){JPanel p=new JPanel(new BorderLayout(0,4));p.setBackground(PANEL);p.setBorder(new EmptyBorder(12,15,12,12));JLabel t=new JLabel(title);t.setFont(new Font("Segoe UI",Font.BOLD,11));t.setForeground(MUTED);value.setFont(new Font("Segoe UI",Font.BOLD,29));value.setForeground(ACCENT);JLabel h=new JLabel(hint);h.setFont(new Font("Segoe UI",Font.PLAIN,10));h.setForeground(MUTED);p.setToolTipText(value.getToolTipText());t.setToolTipText(value.getToolTipText());h.setToolTipText(value.getToolTipText());p.add(t,BorderLayout.NORTH);p.add(value,BorderLayout.CENTER);p.add(h,BorderLayout.SOUTH);return p;}
    static JScrollPane scroll(JComponent c){JScrollPane p=new JScrollPane(c,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);p.setBorder(null);p.getVerticalScrollBar().setUnitIncrement(18);return p;}
    JPanel sidebar(){
        JPanel p=new ScrollPanel();p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));p.setBackground(PANEL);p.setBorder(new EmptyBorder(14,12,14,12));
        add(p,label("КОНСТРУКЦИЯ",true));JPanel size=new JPanel(new FlowLayout(FlowLayout.LEFT,5,6));size.add(new JLabel("X"));size.add(nx);size.add(new JLabel("Y"));size.add(ny);size.add(new JLabel("Z"));size.add(nz);for(JSpinner s:new JSpinner[]{nx,ny,nz})s.setPreferredSize(new Dimension(61,28));add(p,size);
        for(JSpinner s:new JSpinner[]{nx,ny,nz})s.setToolTipText(MetricsPanel.tip("Размер по соответствующей оси: 1…16 клеток. Изменения вступают в силу после нажатия «Применить размер». Вода контура W равна минимуму трёх размеров."));
        for(JSpinner s:new JSpinner[]{nx,ny,nz})((JSpinner.NumberEditor)s.getEditor()).getTextField().setToolTipText(s.getToolTipText());
        add(p,button("Применить размер · до 16³",()->{checkpoint();var next=new MatrixCoefficients.Grid((int)nx.getValue(),(int)ny.getValue(),(int)nz.getValue(),MatrixCoefficients.Material.EMPTY);for(int z=0;z<Math.min(grid.nz,next.nz);z++)for(int y=0;y<Math.min(grid.ny,next.ny);y++)for(int x=0;x<Math.min(grid.nx,next.nx);x++)next.set(x,y,z,grid.get(x,y,z));grid=next;synchronize();changed();}));
        gap(p,16);add(p,label("МАТЕРИАЛ КИСТИ",true));
        JPanel materials=new JPanel(new GridLayout(3,2,6,6));ButtonGroup group=new ButtonGroup();
        for(var m:MatrixCoefficients.Material.values()){
            JToggleButton b=new JToggleButton(name(m));b.setFocusPainted(false);b.setForeground(m==MatrixCoefficients.Material.EMPTY?MUTED:VolumeView.materialColor(m));b.setSelected(m==brush);group.add(b);materials.add(b);b.addActionListener(e->{brush=m;updateMaterial();});
        }add(p,materials);materialInfo.setFont(new Font("Segoe UI",Font.PLAIN,11));materialInfo.setForeground(MUTED);add(p,materialInfo);updateMaterial();
        gap(p,16);add(p,label("РЕДАКТОР СЛОЯ",true));add(p,layerText);add(p,layer);
        editor.setPreferredSize(new Dimension(282,282));editor.setMinimumSize(new Dimension(100,100));editor.setMaximumSize(new Dimension(1000,282));add(p,editor);
        add(p,label("ЛКМ / протяжка — кисть · ПКМ — стереть",false));
        JPanel clipboard=new JPanel(new GridLayout(1,2,5,0));clipboard.add(button("Копировать Ctrl+C",this::copyLayer));clipboard.add(button("Вставить Ctrl+V",this::pasteLayer));add(p,clipboard);gap(p,6);
        JPanel layerActions=new JPanel(new GridLayout(1,2,5,0));layerActions.add(button("Заполнить слой",()->{checkpoint();for(int y=0;y<grid.ny;y++)for(int x=0;x<grid.nx;x++)grid.set(x,y,layer.getValue(),brush);changed();}));layerActions.add(button("Очистить всё",()->{checkpoint();grid=new MatrixCoefficients.Grid(grid.nx,grid.ny,grid.nz,MatrixCoefficients.Material.EMPTY);changed();}));add(p,layerActions);
        JPanel history=new JPanel(new GridLayout(1,2,5,0));history.add(button("Отменить",()->history(false)));history.add(button("Повторить",()->history(true)));gap(p,6);add(p,history);
        gap(p,16);add(p,label("ВЫБРАННАЯ КЛЕТКА",true));add(p,selection);add(p,inspector);
        selection.setToolTipText(MetricsPanel.tip("Координаты X,Y,Z выбранной клетки, начиная с нуля, и материал."));inspector.setToolTipText(MetricsPanel.tip("Потоки и поглощение здесь показаны для сухой конструкции, как в 3D. Локальная H — u/Ubudget; локальная Htv дополнительно учитывает R/N. Температура — игровая шкала плато, NaN при глобальном перегреве."));layerText.setToolTipText(MetricsPanel.tip("Активный слой Z; справа его размеры X×Y. Срез меняет только изображение, не расчёт."));layer.setToolTipText(layerText.getToolTipText());exposure.setToolTipText(MetricsPanel.tip("Экспозиция объёмного свечения; на rawH, Htv, мощности и температуры не влияет."));materialInfo.setToolTipText(MetricsPanel.tip("M — замедление; Af/At — поглощение быстрой/замедленной компоненты; C — коэффициент теплового контакта. Все значения — игровые безразмерные настройки материала."));
        gap(p,16);add(p,label("ЯРКОСТЬ ПОЛЯ",true));add(p,exposure);add(p,label("Экспозиция меняет картинку, не H / L",false));
        gap(p,16);add(p,button("Сохранить изображение…",this::saveImage));
        gap(p,14);JLabel note=new JLabel("<html><div style='width:260px'>Безразмерная игровая модель.<br>Белый / жёлтый → красный → фиолетовый.<br>Чем меньше поток, тем прозрачнее поле.<br>Бор поглощает, но не превращает все частицы в замедленные.</div></html>");note.setForeground(MUTED);note.setFont(new Font("Segoe UI",Font.PLAIN,11));add(p,note);return p;
    }
    void updateMaterial(){materialInfo.setText(brush==MatrixCoefficients.Material.EMPTY?"<html>Прозрачная игровая среда.<br>Не создаёт тепло; перенос и рассеяние сохраняются.</html>":String.format(Locale.ROOT,"<html>M %.2f · Af %.2f · At %.2f · C %.2f</html>",brush.m,brush.af,brush.at,brush.c));}
    static void add(JPanel p,JComponent c){c.setAlignmentX(Component.LEFT_ALIGNMENT);p.add(c);}
    static void gap(JPanel p,int h){p.add(Box.createVerticalStrut(h));}
    static class ScrollPanel extends JPanel implements Scrollable {
        public Dimension getPreferredScrollableViewportSize(){return getPreferredSize();}
        public int getScrollableUnitIncrement(Rectangle r,int o,int d){return 18;}
        public int getScrollableBlockIncrement(Rectangle r,int o,int d){return 180;}
        public boolean getScrollableTracksViewportWidth(){return true;}
        public boolean getScrollableTracksViewportHeight(){return false;}
    }
    static JLabel label(String s,boolean bold){JLabel l=new JLabel(s);l.setFont(new Font("Segoe UI",bold?Font.BOLD:Font.PLAIN,bold?12:11));l.setForeground(bold?TEXT:MUTED);return l;}
    static JButton button(String label,Runnable run){JButton b=new JButton(label);b.setFocusPainted(false);b.setMargin(new Insets(7,10,7,10));b.addActionListener(e->run.run());return b;}
    void key(String key,Runnable run){String id="key-"+key;frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key),id);frame.getRootPane().getActionMap().put(id,new AbstractAction(){public void actionPerformed(ActionEvent e){run.run();}});}
    EditState state(){return new EditState(grid.copy(),loadedRods,layer.getValue());}
    void checkpoint(){undo.push(state());while(undo.size()>40)undo.removeLast();redo.clear();}
    void history(boolean forward){var from=forward?redo:undo;var to=forward?undo:redo;if(from.isEmpty())return;to.push(state());var previous=from.pop();grid=previous.grid;loadedRods=previous.rods;synchronize();layer.setValue(Math.min(previous.layer,grid.nz-1));changed();}
    void synchronize(){updating=true;nx.setValue(grid.nx);ny.setValue(grid.ny);nz.setValue(grid.nz);layer.setMaximum(grid.nz-1);layer.setValue(grid.nz/2);volume.layer=layer.getValue();sx=sy=sz=-1;volume.selected=-1;updating=false;updateLoading();updateLayerLabel();editor.repaint();updateInspector();}
    void updateLoading(){int n=countFuel(grid),cap=ReactorIO.capacity(n);loadedRods=Math.min(loadedRods,cap);updatingRods=true;try{SpinnerNumberModel m=(SpinnerNumberModel)rods.getModel();m.setMaximum(cap);m.setValue(loadedRods);rods.setEnabled(cap>0);}finally{updatingRods=false;}rodCapacity.setText("/ "+cap+" слотов");rodAverage.setText(n==0?"Нет чехлов":String.format(Locale.ROOT,"%.4f ТВЭЛа / чехол",(double)loadedRods/n));}
    void updateTitle(){frame.setTitle("ReaCalc • "+(currentFile==null?"Новая сборка":currentFile.getFileName())+(dirty?" *":""));}
    void copyLayer(){try{layerClipboard.setContents(new StringSelection(LayerCopy.encode(grid,layer.getValue())),null);status.setText("Слой Z="+layer.getValue()+" скопирован ("+grid.nx+" × "+grid.ny+"). Выберите слой и нажмите Ctrl+V.");}catch(IllegalStateException ex){status.setText("Буфер обмена занят. Повторите копирование.");}}
    void pasteLayer(){try{if(!layerClipboard.isDataFlavorAvailable(DataFlavor.stringFlavor))throw new IllegalArgumentException("В буфере нет текстового слоя ReaCalc.");var next=LayerCopy.paste(grid,layer.getValue(),(String)layerClipboard.getData(DataFlavor.stringFlavor));checkpoint();grid=next;changed();status.setText("Слой вставлен в Z="+layer.getValue()+" · Ctrl+Z отменяет вставку целиком");}catch(Exception ex){error(ex);}}
    void updateLayerLabel(){layerText.setText("Z = "+layer.getValue()+" / "+(grid.nz-1)+"    ·    "+grid.nx+" × "+grid.ny);}
    void select(int x,int y,int z){sx=x;sy=y;sz=z;layer.setValue(z);volume.selected=grid.index(x,y,z);updateInspector();editor.repaint();volume.repaint();}
    void setCell(int x,int y,int z,MatrixCoefficients.Material m){grid.set(x,y,z,m);}
    void changed(){dirty=true;revision++;calculated=null;operating=null;updateLoading();heat.setText("…");leak.setText("…");htvLabel.setText("…");score.setText("…");metrics.clear();fuel.setText(Integer.toString(countFuel(grid)));volume.clearField();editor.repaint();updateInspector();status.setText("Изменения внесены · пересчёт поля…");updateTitle();solveTimer.restart();}
    static int countFuel(MatrixCoefficients.Grid g){int n=0;for(int z=0;z<g.nz;z++)for(int y=0;y<g.ny;y++)for(int x=0;x<g.nx;x++)if(g.get(x,y,z)==MatrixCoefficients.Material.FUEL)n++;return n;}
    static VolumeView.Result evaluate(MatrixCoefficients.Grid g){var raw=MatrixCoefficients.analyze(g,RULES);return new VolumeView.Result(g,raw,raw.peakLoad()/HEAT_BUDGET,raw.peakEscape()/(raw.peakEscape()+.10),countFuel(g));}
    void calculate(){
        long id=revision;var snapshot=grid.copy();if(solveTask!=null)solveTask.cancel(true);long start=System.nanoTime();
        solveTask=solver.submit(()->{try{var result=evaluate(snapshot);SwingUtilities.invokeLater(()->{if(id!=revision)return;calculated=result;volume.setResult(result);updateOperating();editor.repaint();});
        }catch(CancellationException ignored){}catch(Exception ex){SwingUtilities.invokeLater(()->{if(id==revision){status.setText("Ошибка расчёта: "+ex.getMessage());error(ex);}});}});
    }
    void updateOperating(){if(calculated==null)return;operating=OperatingMetrics.calculate(calculated,loadedRods);var v=operating;
        heat.setText(MetricsPanel.number(v.rawH(),5));heat.setForeground(ACCENT);leak.setText(MetricsPanel.number(v.rawL()*100,3)+" %");htvLabel.setText(MetricsPanel.number(v.htv(),5));htvLabel.setForeground(v.overheat()?new Color(255,120,130):ACCENT);fuel.setText(Integer.toString(v.sleeves()));score.setText(v.overheat()?"Перегрев":MetricsPanel.number(v.score(),2));metrics.update(v);
        status.setText(String.format(Locale.ROOT,"%d × %d × %d  ·  %s  ·  r = %.5f  ·  3D: сухое поле  ·  Наведите курсор на значение для пояснения",grid.nx,grid.ny,grid.nz,v.overheat()?"Htv ≥ 1 — перегрев":v.rods()==0?"Нет загруженных ТВЭЛов":"Htv < 1 — плато",v.ratio()));updateInspector();}
    void updateInspector(){if(sx<0||!grid.inside(sx,sy,sz)){selection.setText("Выберите клетку в слое или 3D");inspector.setText(" ");return;}selection.setText("["+sx+", "+sy+", "+sz+"]  "+name(grid.get(sx,sy,sz)));
        if(calculated==null){inspector.setText("Пересчёт…");return;}int i=grid.index(sx,sy,sz);var r=calculated.raw();double ratio=calculated.fuels()==0?0:(double)loadedRods/calculated.fuels(),local=r.load()[i]/HEAT_BUDGET*ratio;inspector.setFont(new Font("Consolas",Font.PLAIN,12));inspector.setForeground(MUTED);inspector.setText(String.format(Locale.ROOT,"<html>Быстрый поток: %.5g<br>Замедленный:   %.5g<br>Поглощение:    %.5g<br>Локальная rawH: %.5f<br>Локальная Htv: %.5f<br>T плато: %s</html>",r.fastField()[i],r.slowField()[i],r.absorptionField()[i],r.load()[i]/HEAT_BUDGET,local,MetricsPanel.temp(calculated.h()*ratio>=1?Double.NaN:OperatingMetrics.temperature(local))));}
    boolean confirmLeave(){if(!dirty)return true;int answer=JOptionPane.showOptionDialog(frame,"Сохранить изменения текущей сборки?","Несохранённая сборка",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE,null,new String[]{"Сохранить","Не сохранять","Отмена"},"Сохранить");return answer==1||answer==0&&save(false);}
    static String examplesDirectory(){try{Path location=Path.of(ReaCalc.class.getProtectionDomain().getCodeSource().getLocation().toURI());Path base=Files.isDirectory(location)?location:location.getParent();for(Path root:new Path[]{base,base.getParent()})if(root!=null&&Files.isDirectory(root.resolve("examples")))return root.resolve("examples").toString();}catch(Exception ignored){}return System.getProperty("user.home");}
    JFileChooser chooser(){JFileChooser c=new JFileChooser(currentFile==null?examplesDirectory():currentFile.toAbsolutePath().getParent().toString());c.setAcceptAllFileFilterUsed(false);c.addChoosableFileFilter(new FileNameExtensionFilter("Сборка ReaCalc (*.reacalc)","reacalc"));c.addChoosableFileFilter(new FileNameExtensionFilter("JSON (*.json)","json"));return c;}
    void open(){if(!confirmLeave())return;JFileChooser c=chooser();c.addChoosableFileFilter(new FileNameExtensionFilter("Предыдущая раскладка (*.txt)","txt"));if(c.showOpenDialog(frame)==JFileChooser.APPROVE_OPTION)try{load(c.getSelectedFile().toPath());}catch(Exception ex){error(ex);}}
    void load(Path path)throws Exception{var loaded=ReactorIO.loadDocument(path);checkpoint();grid=loaded.grid();loadedRods=loaded.loadedRods();currentFile=path;revision++;dirty=false;calculated=null;operating=null;metrics.clear();heat.setText("…");htvLabel.setText("…");leak.setText("…");score.setText("…");volume.clearField();synchronize();volume.reset();frame.setTitle("ReaCalc — "+path.getFileName());calculate();}
    boolean save(boolean as){try{rods.commitEdit();Path path=currentFile;if(as||path==null||path.toString().endsWith(".txt")){
            JFileChooser c=chooser();c.setSelectedFile(new java.io.File("reactor.reacalc"));if(c.showSaveDialog(frame)!=JFileChooser.APPROVE_OPTION)return false;path=c.getSelectedFile().toPath();String s=path.toString().toLowerCase(Locale.ROOT);
            if(!s.endsWith(".reacalc")&&!s.endsWith(".json")){String ext=c.getFileFilter() instanceof FileNameExtensionFilter f&&f.getExtensions()[0].equals("json")?".json":".reacalc";path=Path.of(path+ext);}
            if(Files.exists(path)&&JOptionPane.showConfirmDialog(frame,"Заменить "+path.getFileName()+"?","Сохранение",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return false;
        }ReactorIO.saveDocument(path,grid,loadedRods);currentFile=path;dirty=false;frame.setTitle("ReaCalc — "+path.getFileName());status.setText("Сохранено: "+path.toAbsolutePath());return true;}catch(Exception ex){error(ex);return false;}}
    void saveImage(){if(calculated==null)return;JFileChooser c=new JFileChooser();c.setSelectedFile(new java.io.File("reactor.png"));if(c.showSaveDialog(frame)!=JFileChooser.APPROVE_OPTION)return;Path path=c.getSelectedFile().toPath();if(!path.toString().toLowerCase(Locale.ROOT).endsWith(".png"))path=Path.of(path+".png");if(Files.exists(path)&&JOptionPane.showConfirmDialog(frame,"Заменить "+path.getFileName()+"?","Изображение",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
        Path destination=path;var scene=new VolumeView.Scene(calculated,volume.camera(),volume.settings(),1400,1000);
        status.setText("Сохранение изображения…");new SwingWorker<Void,Void>(){protected Void doInBackground()throws Exception{ImageIO.write(snapshot(scene),"png",destination.toFile());return null;}protected void done(){try{get();status.setText("Изображение сохранено: "+destination);}catch(Exception ex){error(ex);}}}.execute();}
    static BufferedImage snapshot(VolumeView.Scene s){BufferedImage out=new BufferedImage(s.width(),s.height(),BufferedImage.TYPE_INT_RGB);Graphics2D g=out.createGraphics();g.setColor(VolumeView.BACK);g.fillRect(0,0,s.width(),s.height());g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);BufferedImage field=VolumeView.renderVolume(s,s.width());if(field!=null)g.drawImage(field,0,0,null);VolumeView.drawGeometry(g,s,-1);VolumeView.drawLegend(g,s.width()-245,32,210,s.settings().mode());g.dispose();return out;}
    void error(Exception ex){JOptionPane.showMessageDialog(frame,ex.getMessage()==null?ex.toString():ex.getMessage(),"ReaCalc",JOptionPane.ERROR_MESSAGE);}
    void shutdown(){solveTimer.stop();solver.shutdownNow();volume.shutdown();}
    static String name(MatrixCoefficients.Material m){return switch(m){case FUEL->"Чехол";case WATER->"Вода";case GRAPHITE->"Графит";case BORON->"Бор";case BARIUM->"Барий";case EMPTY->"Пусто";};}
    static MatrixCoefficients.Grid demo(){var g=new MatrixCoefficients.Grid(9,9,9,MatrixCoefficients.Material.EMPTY);g.set(3,4,4,MatrixCoefficients.Material.FUEL);for(int y=2;y<=6;y++)for(int z=2;z<=6;z++)g.set(5,y,z,MatrixCoefficients.Material.BORON);for(int x=0;x<3;x++)g.set(x,4,4,MatrixCoefficients.Material.GRAPHITE);return g;}
    static MatrixCoefficients.Grid surrounded(MatrixCoefficients.Material m){var g=new MatrixCoefficients.Grid(9,9,9,m);return g.set(4,4,4,MatrixCoefficients.Material.FUEL);}
    static MatrixCoefficients.Grid resource188()throws Exception{try(var in=ReaCalc.class.getResourceAsStream("/best-score-188.txt")){if(in==null)throw new IllegalArgumentException("Встроенный пример недоступен.");return ReactorIO.decodeLegacy(new String(in.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8));}}
    final class SliceEditor extends JPanel {
        int lastIndex=-1;boolean erasing,painting;
        SliceEditor(){setBackground(new Color(17,22,36));setFocusable(true);MouseAdapter m=new MouseAdapter(){
            public void mousePressed(MouseEvent e){requestFocusInWindow();checkpoint();painting=true;erasing=SwingUtilities.isRightMouseButton(e);lastIndex=-1;paintAt(e);}
            public void mouseDragged(MouseEvent e){if(painting)paintAt(e);}
            public void mouseReleased(MouseEvent e){painting=false;lastIndex=-1;}
            void paintAt(MouseEvent e){double cell=cell();int x=(int)Math.floor((e.getX()-offsetX())/cell),y=(int)Math.floor((e.getY()-offsetY())/cell),z=layer.getValue();if(!grid.inside(x,y,z))return;int i=grid.index(x,y,z);if(i==lastIndex)return;lastIndex=i;select(x,y,z);setCell(x,y,z,erasing?MatrixCoefficients.Material.EMPTY:brush);changed();}
        };addMouseListener(m);addMouseMotionListener(m);}
        double cell(){return Math.min((getWidth()-24.)/grid.nx,(getHeight()-24.)/grid.ny);}
        double offsetX(){return(getWidth()-cell()*grid.nx)/2;}
        double offsetY(){return(getHeight()-cell()*grid.ny)/2;}
        protected void paintComponent(Graphics gg){super.paintComponent(gg);Graphics2D g=(Graphics2D)gg.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);double c=cell();int z=layer.getValue();g.setFont(new Font("Segoe UI",Font.BOLD,Math.max(9,(int)Math.min(15,c*.4))));
            for(int y=0;y<grid.ny;y++)for(int x=0;x<grid.nx;x++){int xx=(int)(offsetX()+x*c),yy=(int)(offsetY()+y*c),size=Math.max(1,(int)c-2);var material=grid.get(x,y,z);Color color=VolumeView.materialColor(material);g.setColor(material==MatrixCoefficients.Material.EMPTY?new Color(29,36,53):new Color(color.getRed()/3,color.getGreen()/3,color.getBlue()/3));g.fillRoundRect(xx+1,yy+1,size,size,4,4);g.setColor(new Color(color.getRed(),color.getGreen(),color.getBlue(),material==MatrixCoefficients.Material.EMPTY?65:180));g.drawRoundRect(xx+1,yy+1,size,size,4,4);
                if(c>21&&material!=MatrixCoefficients.Material.EMPTY){String symbol=switch(material){case FUEL->"Ч";case WATER->"В";case GRAPHITE->"Г";case BORON->"Б";case BARIUM->"Ба";case EMPTY->"";};g.setColor(color);FontMetrics fm=g.getFontMetrics();g.drawString(symbol,xx+((int)c-fm.stringWidth(symbol))/2,yy+((int)c+fm.getAscent()-fm.getDescent())/2);}
                if(x==sx&&y==sy&&z==sz){g.setColor(Color.WHITE);g.setStroke(new BasicStroke(2));g.drawRect(xx,yy,(int)c-1,(int)c-1);g.setStroke(new BasicStroke(1));}
            }g.dispose();}
    }
    public static void main(String[] args)throws Exception{
        if(args.length>0&&args[0].equals("--test")){ReaCalcTest.run();return;}
        if(args.length>0&&args[0].equals("--ui-test")){ReaCalcTest.runUi();return;}
        if(args.length>0&&args[0].equals("--assets")){AssetMaker.create(Path.of(args.length>1?args[1]:"."));return;}
        if(args.length>0&&args[0].equals("--metrics")){var doc=ReactorIO.loadDocument(Path.of(args[1]));var values=OperatingMetrics.calculate(evaluate(doc.grid()),args.length>2?Integer.parseInt(args[2]):doc.loadedRods());System.out.println(values);return;}
        if(args.length>0&&args[0].equals("--render")){var r=evaluate(demo());var s=new VolumeView.Scene(r,new VolumeView.Camera(-.68,.48,1.25,0,0),new VolumeView.Settings(0,0,4,4,true),1100,850);ImageIO.write(snapshot(s),"png",Path.of(args.length>1?args[1]:"preview.png").toFile());return;}
        if(args.length>0&&args[0].equals("--snapshot-ui")){SwingUtilities.invokeAndWait(()->{
            theme();ReaCalc app=new ReaCalc();app.revision++;app.solveTimer.stop();if(app.solveTask!=null)app.solveTask.cancel(true);
            try{if(args.length>2){var doc=ReactorIO.loadDocument(Path.of(args[2]));app.grid=doc.grid();app.loadedRods=doc.loadedRods();app.synchronize();}else app.loadedRods=1;if(args.length>3)app.loadedRods=Integer.parseInt(args[3]);ReactorIO.validateRods(app.grid,app.loadedRods);app.updateLoading();if(app.grid.size>1000)app.cut.setSelectedIndex(1);}catch(Exception ex){app.shutdown();app.frame.dispose();throw new RuntimeException(ex);}
            app.frame.addNotify();app.frame.validate();var r=evaluate(app.grid);app.calculated=r;app.volume.setResult(r);app.volume.debounce.stop();app.volume.renderNow();
            app.updateOperating();app.frame.validate();
            BufferedImage image=new BufferedImage(app.frame.getContentPane().getWidth(),app.frame.getContentPane().getHeight(),BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();app.frame.getContentPane().printAll(g);g.dispose();
            try{ImageIO.write(image,"png",Path.of(args.length>1?args[1]:"ui.png").toFile());}catch(Exception ex){throw new RuntimeException(ex);}finally{app.shutdown();app.frame.dispose();}
        });return;}
        SwingUtilities.invokeLater(()->{theme();ReaCalc app=new ReaCalc();app.frame.setVisible(true);if(args.length>0)try{app.load(Path.of(args[0]));}catch(Exception ex){app.error(ex);}});
    }
}
