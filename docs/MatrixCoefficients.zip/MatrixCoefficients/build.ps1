$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
New-Item -ItemType Directory -Path build -Force | Out-Null
javac -encoding UTF-8 --release 21 -d build MatrixCoefficients.java MatrixCoefficientsTest.java
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
jar --create --file MatrixCoefficients.jar --main-class MatrixCoefficients -C build .
if ($LASTEXITCODE -ne 0) { throw 'Packaging failed' }
java -cp build MatrixCoefficientsTest
if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
